
export interface ShareButtonConfig {
  id: string;
  label: string;
  url: string; // Base64 image
}

export interface Brand {
  id: string;
  name: string;
  image?: string; // Base64 logo
}

export interface Category {
  id: string;
  name: string;
}

export interface BackgroundConfig {
  type: 'color' | 'image';
  value: string; // Hex color or Base64 Image string
}

export interface BadgeStyles {
  priceStyle: 'circle' | 'tag' | 'minimal' | 'starburst' | 'arrow';
  promoStyle: 'ribbon' | 'sticker' | 'flag' | 'big-ribbon' | 'discount-tag';
}

export interface ThemeConfig {
  id: string;
  name: string;
  appName?: string;
  catalogTitle?: string; // Slogan o descripción del catálogo
  collectionYear?: string; // Año o nombre de la colección
  logoUrl?: string;
  appBackground: BackgroundConfig;
  cardBackground: BackgroundConfig;
  shareButtons: ShareButtonConfig[];
  darkMode: boolean;
  showPrices?: boolean;
  badges: BadgeStyles;
  colors: {
    brand: string;
    brandContrast: string;
    secondary: string;
    background: string;
    text: string;
  };
  layout: {
    cardSize: 'small' | 'medium' | 'large';
    shadowIntensity?: 'none' | 'low' | 'medium' | 'high';
    brandIconSize?: 'small' | 'medium' | 'large';
    priceBadgeSize?: 'small' | 'medium' | 'large';
    promoBadgeSize?: 'small' | 'medium' | 'large';
  };
  typography: {
    fontFamily: string;
    borderRadius: string;
    headingScale: number;
    textScale: number;
  };
}

export type Language = 'es' | 'en';

export interface Product {
  id: string;
  sku: string;
  name: string;
  brand: string;
  price: number;
  unitPrice?: number;
  originalPrice?: number;
  category: string;
  description: string;
  image: string;
  images?: string[];
  stock: number;
  isFeatured: boolean;
  isPromotion?: boolean;
  season?: string; // Nueva propiedad para Temporada
  lastUpdated: number;
  unitsPerBox?: number;
  unitsPerDisplay?: number;
  priceScales?: { minQuantity: number; price: number }[];
}

export const DEFAULT_THEME: ThemeConfig = {
  id: 'default',
  name: 'Best Partner Theme',
  appName: 'BEST PARTNER',
  catalogTitle: 'Descubre nuestra selección exclusiva de productos para tu negocio.',
  collectionYear: '2025',
  logoUrl: '',
  appBackground: { type: 'color', value: '#f3f4f6' },
  cardBackground: { type: 'color', value: '#ffffff' },
  shareButtons: [],
  darkMode: false,
  showPrices: true,
  badges: {
    priceStyle: 'arrow',
    promoStyle: 'discount-tag'
  },
  colors: {
    brand: '#800020',
    brandContrast: '#ffffff',
    secondary: '#f3f4f6',
    background: '#ffffff',
    text: '#1f2937',
  },
  layout: {
    cardSize: 'medium',
    shadowIntensity: 'medium',
    brandIconSize: 'medium',
    priceBadgeSize: 'medium',
    promoBadgeSize: 'medium',
  },
  typography: {
    fontFamily: 'Inter',
    borderRadius: '0.75rem',
    headingScale: 1,
    textScale: 1,
  }
};
