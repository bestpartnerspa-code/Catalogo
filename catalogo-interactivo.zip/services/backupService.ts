
import { dbService } from './db';
import { Product, ThemeConfig, Brand, Category } from '../types';

interface BackupData {
  version: number;
  timestamp: number;
  products: Product[];
  brands: Brand[];
  categories: Category[];
  theme: ThemeConfig;
  images: { url: string; data: string }[]; // Base64 image data
}

export const backupService = {
  // Helper: Blob to Base64
  blobToBase64: (blob: Blob): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result as string);
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  },

  // Helper: Base64 to Blob
  base64ToBlob: async (base64: string): Promise<Blob> => {
    const res = await fetch(base64);
    return await res.blob();
  },

  createBackup: async (): Promise<Blob> => {
    await dbService.connect();
    
    // 1. Fetch all data
    const products = await dbService.getAllProducts();
    const brands = await dbService.getBrands();
    const categories = await dbService.getCategories();
    const theme = await dbService.getTheme();
    
    // 2. Extract all unique image URLs from products and brands
    const imageUrls = new Set<string>();
    products.forEach(p => {
      if (p.image) imageUrls.add(p.image);
      if (p.images) p.images.forEach(i => imageUrls.add(i));
    });
    brands.forEach(b => {
      if (b.image) imageUrls.add(b.image);
    });
    if (theme.appBackground.type === 'image') imageUrls.add(theme.appBackground.value);
    if (theme.cardBackground.type === 'image') imageUrls.add(theme.cardBackground.value);
    if (theme.logoUrl) imageUrls.add(theme.logoUrl);
    theme.shareButtons.forEach(b => imageUrls.add(b.url));

    // 3. Serialize Blobs from IndexedDB to Base64
    const serializedImages: { url: string; data: string }[] = [];
    
    for (const url of Array.from(imageUrls)) {
      // Only process blob URLs or local references, skip external http unless cached
      try {
        const blob = await dbService.getCachedImage(url);
        if (blob) {
          const base64 = await backupService.blobToBase64(blob);
          serializedImages.push({ url, data: base64 });
        }
      } catch (e) {
        console.warn('Could not backup image:', url);
      }
    }

    const backupData: BackupData = {
      version: 1,
      timestamp: Date.now(),
      products,
      brands,
      categories,
      theme,
      images: serializedImages
    };

    const jsonString = JSON.stringify(backupData);
    return new Blob([jsonString], { type: 'application/json' });
  },

  restoreBackup: async (file: File): Promise<void> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = async (e) => {
        try {
          const json = e.target?.result as string;
          const data: BackupData = JSON.parse(json);

          // Basic Validation
          if (!data.products || !data.theme) {
            throw new Error("El archivo de respaldo no es válido o está corrupto.");
          }

          await dbService.connect();

          // 1. Restore Images first (Keep as loop, images need individual processing)
          if (data.images && Array.isArray(data.images)) {
             for (const img of data.images) {
                try {
                  const blob = await backupService.base64ToBlob(img.data);
                  await dbService.saveCachedImage(img.url, blob);
                } catch (err) {
                  console.warn("Failed to restore image", img.url);
                }
             }
          }

          // 2. Clear Existing Data (Products, Brands, Categories)
          await dbService.clearAllData();
          
          // 3. Restore Data Tables using BULK operations for speed and stability
          // Note: We use || [] to ensure even if empty in backup, it doesn't crash
          if (data.products?.length > 0) {
              await dbService.bulkPutProducts(data.products);
          }
          
          if (data.brands?.length > 0) {
              await dbService.bulkPutBrands(data.brands);
          }
          
          if (data.categories?.length > 0) {
              await dbService.bulkPutCategories(data.categories);
          }

          // 4. Restore Theme
          await dbService.saveTheme(data.theme);

          resolve();
        } catch (err) {
          console.error("Restoration Error:", err);
          reject(err);
        }
      };
      reader.onerror = () => reject(new Error("Error leyendo el archivo"));
      reader.readAsText(file);
    });
  }
};
