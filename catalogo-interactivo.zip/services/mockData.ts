
import { Product } from '../types';

export const INITIAL_PRODUCTS: Product[] = [
  // --- SNACKS MARCO POLO (Página 2, 3, 4) ---
  {
    id: 'mp-clasicas',
    sku: 'MP-001',
    name: 'Papas Marco Polo Clásicas (Surtido)',
    brand: 'Marco Polo',
    price: 7250, // 1450 * 5
    unitPrice: 1450,
    category: 'Snacks',
    description: 'Papas fritas 100% naturales. Sabores: Crema Ciboulette, Limón, Jamón Serrano, Barbeque.',
    image: 'https://images.unsplash.com/photo-1566478989037-eec170784d0b?q=80&w=800',
    isFeatured: true,
    season: 'Todo el año',
    stock: 100,
    lastUpdated: Date.now(),
    unitsPerDisplay: 5,
    priceScales: [
      { minQuantity: 5, price: 1450 },
      { minQuantity: 16, price: 1300 }
    ]
  },
  {
    id: 'mp-kraft-mustard',
    sku: 'MP-002',
    name: 'Marco Polo Sabor Kraft Mustard',
    brand: 'Marco Polo',
    price: 1500,
    unitPrice: 1500,
    category: 'Snacks',
    description: 'Edición Limitada Sabor Real Mustard Kraft.',
    image: 'https://images.unsplash.com/photo-1613919113184-7bd104961655?q=80&w=800',
    isFeatured: false,
    season: 'Verano',
    stock: 50,
    lastUpdated: Date.now(),
    unitsPerDisplay: 1
  },
  {
    id: 'mp-americano-140',
    sku: 'MP-003',
    name: 'Papas Corte Americano 140g',
    brand: 'Marco Polo',
    price: 1000,
    unitPrice: 1000,
    category: 'Snacks',
    description: 'Corte Americano 140g - A Luka.',
    image: 'https://images.unsplash.com/photo-1599490659213-e2b9527bb087?q=80&w=800',
    isFeatured: false,
    season: 'Todo el año',
    stock: 200,
    lastUpdated: Date.now()
  },

  // --- TABAQUERIA (Página 6, 7) ---
  {
    id: 'tab-ronson-20',
    sku: 'RON-20',
    name: 'Encendedores Ronson Display',
    brand: 'Ronson',
    price: 4800,
    unitPrice: 240,
    category: 'Tabaquería',
    description: 'Display de 20 encendedores clásicos Ronson.',
    image: 'https://images.unsplash.com/photo-1523293836414-f04e712e1f3b?q=80&w=800',
    isFeatured: true,
    season: 'Todo el año',
    stock: 30,
    lastUpdated: Date.now(),
    unitsPerDisplay: 20
  },
  {
    id: 'tab-ocb-premium',
    sku: 'OCB-PREM',
    name: 'Papelillos OCB Premium',
    brand: 'OCB',
    price: 14500,
    unitPrice: 580,
    category: 'Tabaquería',
    description: 'Display de 25 packs x 50 hojas.',
    image: 'https://images.unsplash.com/photo-1620177264421-460d00f68481?q=80&w=800',
    isFeatured: false,
    season: 'Todo el año',
    stock: 15,
    lastUpdated: Date.now(),
    unitsPerDisplay: 25
  },

  // --- CONFITES COLOMBINA (Página 8, 9, 10) ---
  {
    id: 'col-bonbonbum',
    sku: 'BBB-01',
    name: 'Bon Bon Bum Fresa / Surtido',
    brand: 'Colombina',
    price: 5500,
    unitPrice: 230,
    category: 'Confites',
    description: 'Chupetes rellenos de chicle. Sabores: Fresa, Mistery, Sandía Sensations.',
    image: 'https://images.unsplash.com/photo-1575224300306-1b8da36134ec?q=80&w=800',
    isFeatured: true,
    season: 'Escolar',
    stock: 60,
    lastUpdated: Date.now(),
    unitsPerDisplay: 24
  },
  {
    id: 'col-gomela-80',
    sku: 'GOM-80',
    name: 'Gomita Gomela 80g',
    brand: 'Colombina',
    price: 550,
    unitPrice: 550,
    category: 'Confites',
    description: 'Gomitas Splash Ácidos / Bonbonbum Fresa 80g.',
    image: 'https://images.unsplash.com/photo-1581798459219-318e76aecc7b?q=80&w=800',
    isFeatured: false,
    season: 'Todo el año',
    stock: 120,
    lastUpdated: Date.now()
  },

  // --- TRENTO & CHOCOLATES (Página 11) ---
  {
    id: 'cho-trento-16',
    sku: 'TRN-16',
    name: 'Trento Wafle Chocolate',
    brand: 'Trento',
    price: 9600,
    unitPrice: 600,
    category: 'Chocolates',
    description: 'Wafle relleno y bañado con chocolate. Display 16 unds.',
    image: 'https://images.unsplash.com/photo-1548907040-4baa42d10919?q=80&w=800',
    isFeatured: true,
    season: 'Invierno',
    stock: 40,
    lastUpdated: Date.now(),
    unitsPerDisplay: 16
  },
  {
    id: 'cho-dubai-rb',
    sku: 'DUB-24',
    name: 'Chocolate Dubai Rosso Bianco',
    brand: 'Rosso Bianco',
    price: 22800,
    unitPrice: 950,
    category: 'Chocolates',
    description: 'Chocolate premium tipo Dubai. Agotado según catálogo.',
    image: 'https://images.unsplash.com/photo-1606312619070-d48b4c652a52?q=80&w=800',
    isFeatured: false,
    season: 'Invierno',
    stock: 0, // Marcado como AGOTADO en catálogo
    lastUpdated: Date.now(),
    unitsPerDisplay: 24
  },

  // --- CONFITES MABÚ (Página 13, 14, 15) ---
  {
    id: 'mabu-jalea-chanchito',
    sku: 'MAB-01',
    name: 'Jalea Chanchito Display',
    brand: 'Confites Mabú',
    price: 5400,
    unitPrice: 54,
    category: 'Gomitas y Jaleas',
    description: 'Jaleas en formato Chanchito. Display de 100 unds.',
    image: 'https://images.unsplash.com/photo-1499195333224-3ce974e379a7?q=80&w=800',
    isFeatured: false,
    season: 'Escolar',
    stock: 45,
    lastUpdated: Date.now(),
    unitsPerDisplay: 100
  },
  {
    id: 'mabu-ojos-locos',
    sku: 'MAB-02',
    name: 'Gomita Ojos Locos',
    brand: 'Confites Mabú',
    price: 3650,
    unitPrice: 122,
    category: 'Gomitas y Jaleas',
    description: 'Gomitas con forma de ojo. Contiene 30 unds.',
    image: 'https://images.unsplash.com/photo-1534120247760-c44c3e4a62f1?q=80&w=800',
    isFeatured: false,
    season: 'Halloween',
    stock: 30,
    lastUpdated: Date.now(),
    unitsPerDisplay: 30
  },

  // --- CONFITERIA ARTESANAL (Página 25, 26) ---
  {
    id: 'art-helado-grande',
    sku: 'ART-01',
    name: 'Helado de Invierno Grande',
    brand: 'Confitería Artesanal',
    price: 3200,
    unitPrice: 160,
    category: 'Artesanal',
    description: 'Helado de invierno artesanal. Display de 20 unds.',
    image: 'https://images.unsplash.com/photo-1559181567-c3190cb9959b?q=80&w=800',
    isFeatured: true,
    season: 'Invierno',
    stock: 25,
    lastUpdated: Date.now(),
    unitsPerDisplay: 20
  },
  {
    id: 'art-enpolvados',
    sku: 'ART-02',
    name: 'Enpolvados Artesanales',
    brand: 'Confitería Artesanal',
    price: 3000,
    unitPrice: 150,
    category: 'Artesanal',
    description: 'Bocados dulces enpolvados. Contiene 20 unds.',
    image: 'https://images.unsplash.com/photo-1519340333755-5c0d616d7242?q=80&w=800',
    isFeatured: false,
    season: 'Fiestas Patrias',
    stock: 15,
    lastUpdated: Date.now(),
    unitsPerDisplay: 20
  },

  // --- AGUAS (Página 5, 27) ---
  {
    id: 'agua-cotti-6',
    sku: 'AG-001',
    name: 'Agua Soda Cotti X6 2LT',
    brand: 'Cotti',
    price: 6500,
    category: 'Bebidas',
    description: 'Pack de 6 botellas de agua soda de 2 litros.',
    image: 'https://images.unsplash.com/photo-1559839914-17aae19cea0e?q=80&w=800',
    isFeatured: false,
    season: 'Verano',
    stock: 40,
    lastUpdated: Date.now(),
    unitsPerDisplay: 6
  },
  {
    id: 'agua-arka-20l',
    sku: 'ARKA-20',
    name: 'Recarga Agua Purificada 20L',
    brand: 'Arka',
    price: 24000,
    unitPrice: 1200,
    category: 'Agua Purificada',
    description: 'Pack de 20 recargas de 20 litros. Precio cliente: $1.200 c/u.',
    image: 'https://images.unsplash.com/photo-1523362628745-0c100150b504?q=80&w=800',
    isFeatured: true,
    season: 'Todo el año',
    stock: 20,
    lastUpdated: Date.now(),
    unitsPerDisplay: 20
  }
];
