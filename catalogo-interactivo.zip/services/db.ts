
import { Product, ThemeConfig, DEFAULT_THEME, Brand, Category } from '../types';

// Simple implementation of IndexedDB logic to avoid external dependencies like Dexie for this demo
// In a real production app, Dexie.js or RxDB is recommended.

const DB_NAME = 'OmniCatalogDB';
const DB_VERSION = 3; // Incremented for Brands and Categories
const STORE_PRODUCTS = 'products';
const STORE_SETTINGS = 'settings';
const STORE_IMAGES = 'images';
const STORE_BRANDS = 'brands';
const STORE_CATEGORIES = 'categories';

export class OfflineDB {
  private db: IDBDatabase | null = null;

  async connect(): Promise<void> {
    if (this.db) return; 

    return new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);

      request.onerror = () => reject(request.error);
      request.onsuccess = () => {
        this.db = request.result;
        resolve();
      };

      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;
        if (!db.objectStoreNames.contains(STORE_PRODUCTS)) {
          db.createObjectStore(STORE_PRODUCTS, { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains(STORE_SETTINGS)) {
          db.createObjectStore(STORE_SETTINGS, { keyPath: 'key' });
        }
        if (!db.objectStoreNames.contains(STORE_IMAGES)) {
          db.createObjectStore(STORE_IMAGES); // Key is URL string, value is Blob
        }
        if (!db.objectStoreNames.contains(STORE_BRANDS)) {
          db.createObjectStore(STORE_BRANDS, { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains(STORE_CATEGORIES)) {
          db.createObjectStore(STORE_CATEGORIES, { keyPath: 'id' });
        }
      };
    });
  }

  async getAllProducts(): Promise<Product[]> {
    return this.performTransaction<Product[]>(STORE_PRODUCTS, 'readonly', (store) => store.getAll());
  }

  async bulkPutProducts(products: Product[]): Promise<void> {
    if (!this.db) await this.connect();
    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(STORE_PRODUCTS, 'readwrite');
      const store = transaction.objectStore(STORE_PRODUCTS);
      
      products.forEach(p => store.put(p));

      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(transaction.error);
    });
  }
  
  async deleteProduct(id: string): Promise<void> {
    return this.performTransaction<void>(STORE_PRODUCTS, 'readwrite', (store) => store.delete(id));
  }

  // --- Bulk Methods for Restore Functionality ---
  
  async bulkPutBrands(brands: Brand[]): Promise<void> {
    if (!this.db) await this.connect();
    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(STORE_BRANDS, 'readwrite');
      const store = transaction.objectStore(STORE_BRANDS);
      brands.forEach(b => store.put(b));
      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(transaction.error);
    });
  }

  async bulkPutCategories(categories: Category[]): Promise<void> {
    if (!this.db) await this.connect();
    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(STORE_CATEGORIES, 'readwrite');
      const store = transaction.objectStore(STORE_CATEGORIES);
      categories.forEach(c => store.put(c));
      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(transaction.error);
    });
  }

  async clearAllData(): Promise<void> {
    if (!this.db) await this.connect();
    return new Promise((resolve, reject) => {
      // Clear all data stores in a single transaction
      const transaction = this.db!.transaction([STORE_PRODUCTS, STORE_BRANDS, STORE_CATEGORIES], 'readwrite');
      
      transaction.objectStore(STORE_PRODUCTS).clear();
      transaction.objectStore(STORE_BRANDS).clear();
      transaction.objectStore(STORE_CATEGORIES).clear();
      
      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(transaction.error);
    });
  }

  async saveTheme(theme: ThemeConfig): Promise<void> {
    if (!this.db) await this.connect();
    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(STORE_SETTINGS, 'readwrite');
      const store = transaction.objectStore(STORE_SETTINGS);
      store.put({ key: 'active_theme', value: theme });
      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(transaction.error);
    });
  }

  async getTheme(): Promise<ThemeConfig> {
    if (!this.db) await this.connect();
    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(STORE_SETTINGS, 'readonly');
      const store = transaction.objectStore(STORE_SETTINGS);
      const request = store.get('active_theme');
      request.onsuccess = () => resolve(request.result?.value || DEFAULT_THEME);
      request.onerror = () => reject(request.error);
    });
  }

  async clearCatalog(): Promise<void> {
    if (!this.db) await this.connect();
     return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(STORE_PRODUCTS, 'readwrite');
      const store = transaction.objectStore(STORE_PRODUCTS);
      store.clear();
      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(transaction.error);
    });
  }

  // --- Master Lists Methods (Brands & Categories) ---

  async getBrands(): Promise<Brand[]> {
    return this.performTransaction<Brand[]>(STORE_BRANDS, 'readonly', (store) => store.getAll());
  }

  async saveBrand(brand: Brand): Promise<void> {
    return this.performTransaction<void>(STORE_BRANDS, 'readwrite', (store) => store.put(brand));
  }

  async deleteBrand(id: string): Promise<void> {
    return this.performTransaction<void>(STORE_BRANDS, 'readwrite', (store) => store.delete(id));
  }

  async getCategories(): Promise<Category[]> {
    return this.performTransaction<Category[]>(STORE_CATEGORIES, 'readonly', (store) => store.getAll());
  }

  async saveCategory(category: Category): Promise<void> {
    return this.performTransaction<void>(STORE_CATEGORIES, 'readwrite', (store) => store.put(category));
  }

  async deleteCategory(id: string): Promise<void> {
    return this.performTransaction<void>(STORE_CATEGORIES, 'readwrite', (store) => store.delete(id));
  }


  // --- Image Caching Methods ---

  async getCachedImage(url: string): Promise<Blob | undefined> {
    if (!this.db) await this.connect();
    return new Promise((resolve) => {
      try {
        const transaction = this.db!.transaction(STORE_IMAGES, 'readonly');
        const store = transaction.objectStore(STORE_IMAGES);
        const request = store.get(url);
        // Explicitly cast request.result to Blob | undefined to avoid 'unknown' type errors
        request.onsuccess = () => resolve(request.result as Blob | undefined);
        request.onerror = () => {
          console.warn("Image cache lookup failed for", url);
          resolve(undefined);
        };
      } catch (e) {
        resolve(undefined);
      }
    });
  }

  async saveCachedImage(url: string, blob: Blob): Promise<void> {
    if (!this.db) await this.connect();
    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(STORE_IMAGES, 'readwrite');
      const store = transaction.objectStore(STORE_IMAGES);
      try {
        store.put(blob, url);
        transaction.oncomplete = () => resolve();
        transaction.onerror = () => reject(transaction.error);
      } catch (e) {
        // Quota exceeded or other error
        reject(e);
      }
    });
  }

  private async performTransaction<T>(storeName: string, mode: IDBTransactionMode, operation: (store: IDBObjectStore) => IDBRequest): Promise<T> {
    if (!this.db) await this.connect();
    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(storeName, mode);
      const store = transaction.objectStore(storeName);
      const request = operation(store);
      
      // Explicitly cast request.result to T to avoid 'unknown' type errors
      request.onsuccess = () => resolve(request.result as T);
      request.onerror = () => reject(request.error);
    });
  }
}

export const dbService = new OfflineDB();
