
import React, { useState, useEffect, useMemo } from 'react';
import { ThemeProvider, useTheme } from './contexts/ThemeContext';
import { SettingsProvider, useSettings } from './contexts/SettingsContext';
import Navigation from './components/Navigation';
import Catalog from './components/Catalog';
import AdminPanel from './components/AdminPanel';
import QuoteModal from './components/QuoteModal';
import CatalogPdfModal from './components/CatalogPdfModal';
import { Product, Brand } from './types';
import { X, Settings, FileDown, Sun, Moon, Briefcase, Tag, Layout, ChevronRight, Share2, ChevronDown, Calendar } from 'lucide-react';
import { dbService } from './services/db';
import { INITIAL_PRODUCTS } from './services/mockData';

const InnerApp: React.FC = () => {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [products, setProducts] = useState<Product[]>([]);
  const [brands, setBrands] = useState<Brand[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [cart, setCart] = useState<Product[]>([]);
  const [view, setView] = useState<'catalog' | 'admin'>('catalog');
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isQuoteModalOpen, setIsQuoteModalOpen] = useState(false);
  const [isCatalogPdfOpen, setIsCatalogPdfOpen] = useState(false);
  
  // Filters State
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedBrand, setSelectedBrand] = useState<string | null>(null);
  const [selectedSeason, setSelectedSeason] = useState<string | null>(null);
  
  // Sidebar Toggles
  const [isCategoriesExpanded, setIsCategoriesExpanded] = useState(true);
  const [isBrandsExpanded, setIsBrandsExpanded] = useState(true);
  const [isSeasonsExpanded, setIsSeasonsExpanded] = useState(true);

  const { t, getDisplayPrice } = useSettings();
  const { theme, toggleDarkMode } = useTheme();

  const loadData = async () => {
    setIsLoading(true);
    try {
      await dbService.connect();
      let storedProducts = await dbService.getAllProducts();
      if (storedProducts.length === 0) {
        await dbService.bulkPutProducts(INITIAL_PRODUCTS);
        storedProducts = INITIAL_PRODUCTS;
      }
      const storedBrands = await dbService.getBrands();
      setProducts(storedProducts);
      setBrands(storedBrands);
    } catch (err) { console.error(err); } finally { setIsLoading(false); }
  };

  useEffect(() => {
    loadData();
    window.addEventListener('catalogUpdated', loadData);
    return () => window.removeEventListener('catalogUpdated', loadData);
  }, []);

  const categories = useMemo(() => Array.from(new Set(products.map(p => p.category))).sort(), [products]);
  const brandNames = useMemo(() => Array.from(new Set(products.map(p => p.brand))).filter(Boolean).sort(), [products]);
  const seasons = useMemo(() => Array.from(new Set(products.map(p => p.season))).filter(Boolean).sort(), [products]);

  const filteredProducts = useMemo(() => {
    return products.filter(p => {
        const catMatch = selectedCategory ? p.category === selectedCategory : true;
        const brandMatch = selectedBrand ? p.brand === selectedBrand : true;
        const seasonMatch = selectedSeason ? p.season === selectedSeason : true;
        return catMatch && brandMatch && seasonMatch;
    });
  }, [products, selectedCategory, selectedBrand, selectedSeason]);

  const cartGroups = useMemo(() => {
    const groups: { [key: string]: { product: Product; count: number } } = {};
    cart.forEach(p => {
      if (!groups[p.id]) groups[p.id] = { product: p, count: 0 };
      groups[p.id].count++;
    });
    return Object.values(groups);
  }, [cart]);

  const cartTotal = useMemo(() => cart.reduce((sum, p) => sum + getDisplayPrice(p.price), 0), [cart, getDisplayPrice]);

  const updateQuantity = (product: Product, delta: number) => {
    if (delta > 0) {
      setCart(prev => [...prev, product]);
    } else {
      setCart(prev => {
        // findLastIndex is not available in some older TS targets, using a backward loop instead
        let lastIndex = -1;
        for (let i = prev.length - 1; i >= 0; i--) {
          if (prev[i].id === product.id) {
            lastIndex = i;
            break;
          }
        }
        
        if (lastIndex > -1) {
          const newCart = [...prev];
          newCart.splice(lastIndex, 1);
          return newCart;
        }
        return prev;
      });
    }
  };

  const shareImage = async (url: string, title: string) => {
    if (!url) return;
    try {
        let blob = await dbService.getCachedImage(url);
        if (!blob && url.startsWith('data:')) {
             const res = await fetch(url);
             blob = await res.blob();
        }

        if (!blob) {
             alert("Error al procesar la imagen.");
             return;
        }

        const file = new File([blob], "promo.jpg", { type: "image/jpeg" });
        if (navigator.canShare && navigator.canShare({ files: [file] })) {
            await navigator.share({
                files: [file],
                title: title,
                text: `¡Mira esta información de ${theme.appName}!`
            });
        } else {
            alert("Tu dispositivo no soporta compartir imágenes directamente desde esta app.");
        }
    } catch (e) {
        console.error("Share error:", e);
        alert("Hubo un error al intentar compartir.");
    }
    setIsMenuOpen(false);
  };

  return (
    <div className={`min-h-screen transition-colors duration-500 ${theme.darkMode ? 'dark bg-zinc-950 text-white' : 'bg-gray-100 text-gray-900'}`} style={{ fontFamily: theme.typography.fontFamily }}>
      <Navigation isOnline={isOnline} cartCount={cart.length} onOpenMenu={() => setIsMenuOpen(true)} onOpenCart={() => setIsQuoteModalOpen(true)} />

      <main className="pt-24 flex max-w-7xl mx-auto px-4 sm:px-6">
        {view === 'catalog' && (
            <aside className="hidden lg:block w-64 pr-8 sticky top-28 self-start h-[calc(100vh-8rem)] overflow-y-auto no-scrollbar">
                
                {/* CATEGORIES */}
                <div className="mb-8">
                    <button 
                      onClick={() => setIsCategoriesExpanded(!isCategoriesExpanded)}
                      className="flex items-center justify-between w-full mb-4 pb-1 border-b dark:border-white/10 group cursor-pointer"
                    >
                      <h3 className="font-black text-gray-400 uppercase tracking-widest text-[10px] group-hover:text-brand transition-colors">{t('categories')}</h3>
                      <ChevronDown size={14} className={`text-gray-400 transition-transform duration-300 ${isCategoriesExpanded ? 'rotate-180' : ''}`} />
                    </button>
                    
                    {isCategoriesExpanded && (
                      <div className="space-y-1 animate-in fade-in slide-in-from-top-2 duration-200">
                        <button onClick={() => {setSelectedCategory(null); setSelectedBrand(null); setSelectedSeason(null);}} className={`w-full text-left px-4 py-2.5 rounded-xl text-xs font-black uppercase transition-all ${!selectedCategory && !selectedBrand && !selectedSeason ? 'bg-brand text-white shadow-lg' : 'text-gray-500 hover:bg-black/5 dark:hover:bg-white/5'}`}>Todo</button>
                        {categories.map(cat => (
                            <button key={cat} onClick={() => {setSelectedCategory(cat); setSelectedBrand(null); setSelectedSeason(null);}} className={`w-full text-left px-4 py-2.5 rounded-xl text-xs font-black uppercase transition-all ${selectedCategory === cat ? 'bg-brand text-white shadow-lg' : 'text-gray-500 hover:bg-black/5 dark:hover:bg-white/5'}`}>{cat}</button>
                        ))}
                      </div>
                    )}
                </div>

                {/* BRANDS */}
                <div className="mb-8">
                    <button 
                      onClick={() => setIsBrandsExpanded(!isBrandsExpanded)}
                      className="flex items-center justify-between w-full mb-4 pb-1 border-b dark:border-white/10 group cursor-pointer"
                    >
                      <h3 className="font-black text-gray-400 uppercase tracking-widest text-[10px] group-hover:text-brand transition-colors">{t('brands')}</h3>
                      <ChevronDown size={14} className={`text-gray-400 transition-transform duration-300 ${isBrandsExpanded ? 'rotate-180' : ''}`} />
                    </button>

                    {isBrandsExpanded && (
                      <div className="space-y-1 animate-in fade-in slide-in-from-top-2 duration-200">
                        {brandNames.map(brand => (
                            <button key={brand} onClick={() => {setSelectedBrand(brand); setSelectedCategory(null); setSelectedSeason(null);}} className={`w-full text-left px-4 py-2.5 rounded-xl text-xs font-black uppercase transition-all ${selectedBrand === brand ? 'bg-brand text-white shadow-lg' : 'text-gray-500 hover:bg-black/5 dark:hover:bg-white/5'}`}>{brand}</button>
                        ))}
                      </div>
                    )}
                </div>

                {/* SEASONS */}
                <div className="mb-8">
                    <button 
                      onClick={() => setIsSeasonsExpanded(!isSeasonsExpanded)}
                      className="flex items-center justify-between w-full mb-4 pb-1 border-b dark:border-white/10 group cursor-pointer"
                    >
                      <h3 className="font-black text-gray-400 uppercase tracking-widest text-[10px] group-hover:text-brand transition-colors">TEMPORADAS</h3>
                      <ChevronDown size={14} className={`text-gray-400 transition-transform duration-300 ${isSeasonsExpanded ? 'rotate-180' : ''}`} />
                    </button>

                    {isSeasonsExpanded && (
                      <div className="space-y-1 animate-in fade-in slide-in-from-top-2 duration-200">
                        {seasons.map(season => (
                            <button key={season as string} onClick={() => {setSelectedSeason(season as string); setSelectedCategory(null); setSelectedBrand(null);}} className={`w-full text-left px-4 py-2.5 rounded-xl text-xs font-black uppercase transition-all ${selectedSeason === season ? 'bg-brand text-white shadow-lg' : 'text-gray-500 hover:bg-black/5 dark:hover:bg-white/5'}`}>{season as string}</button>
                        ))}
                        {seasons.length === 0 && <p className="text-[10px] px-4 py-2 text-gray-400">Sin temporadas asignadas</p>}
                      </div>
                    )}
                </div>
            </aside>
        )}

        <div className="flex-1 min-w-0">
            {view === 'admin' ? (
              <AdminPanel onBack={() => setView('catalog')} />
            ) : (
              <Catalog 
                products={filteredProducts} 
                allProducts={products}
                brands={brands} 
                isLoading={isLoading} 
                onAddToCart={(p) => updateQuantity(p, 1)} 
                onUpdateQuantity={updateQuantity} 
                cart={cart} 
                activeCategory={selectedCategory || selectedBrand || selectedSeason} 
                onClearFilters={() => {setSelectedCategory(null); setSelectedBrand(null); setSelectedSeason(null);}} 
              />
            )}
        </div>
      </main>

      {/* Menu Drawer */}
      {isMenuOpen && (
        <div className="fixed inset-0 z-[100] flex">
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setIsMenuOpen(false)}></div>
          <div className="relative w-80 max-w-[85%] shadow-2xl flex flex-col h-full animate-in slide-in-from-left duration-300 bg-brand text-white">
            <div className="p-6 border-b border-white/10 flex justify-between items-center">
                <span className="font-black text-2xl tracking-tighter uppercase">{theme.appName || 'MENÚ'}</span>
                <button onClick={() => setIsMenuOpen(false)} className="p-2 hover:bg-white/10 rounded-full transition-colors"><X size={28} /></button>
            </div>
            
            <div className="p-6 flex-1 overflow-y-auto space-y-6 no-scrollbar">
                <div className="space-y-2">
                    <h4 className="text-[10px] font-black text-white/40 uppercase tracking-widest mb-2 px-4">Explorar</h4>
                    <button 
                      onClick={() => { 
                          setView('catalog'); 
                          setSelectedCategory(null); 
                          setSelectedBrand(null); 
                          setSelectedSeason(null);
                          setIsMenuOpen(false); 
                      }} 
                      className={`w-full text-left px-4 py-3 rounded-xl flex items-center space-x-3 ${view === 'catalog' && !selectedCategory && !selectedBrand && !selectedSeason ? 'bg-white text-brand font-black shadow-lg' : 'hover:bg-white/10'}`}
                    >
                      <Layout size={20}/> <span className="font-black text-xs uppercase">Catálogo</span>
                    </button>
                    <button onClick={() => { setIsCatalogPdfOpen(true); setIsMenuOpen(false); }} className="w-full text-left px-4 py-3 rounded-xl flex items-center space-x-3 hover:bg-white/10"><FileDown size={20}/> <span className="font-black text-xs uppercase">Generar Catálogo PDF</span></button>
                    
                    {(theme.shareButtons || []).map((btn) => (
                        <button key={btn.id} onClick={() => shareImage(btn.url, btn.label)} className="w-full text-left px-4 py-3 rounded-xl flex items-center space-x-3 hover:bg-white/10">
                            <Share2 size={20}/> <span className="font-black text-xs uppercase">{btn.label}</span>
                        </button>
                    ))}
                </div>

                <div className="space-y-1">
                    <h4 className="text-[10px] font-black text-white/40 uppercase tracking-widest mb-2 px-4">Categorías</h4>
                    {categories.map(cat => (
                        <button key={cat} onClick={() => {setSelectedCategory(cat); setSelectedBrand(null); setSelectedSeason(null); setIsMenuOpen(false); setView('catalog');}} className={`w-full text-left px-4 py-2 rounded-xl flex items-center justify-between text-[11px] font-bold uppercase transition-all ${selectedCategory === cat ? 'bg-white/20' : 'hover:bg-white/5'}`}>
                            {cat} <ChevronRight size={14} className="opacity-40"/>
                        </button>
                    ))}
                </div>

                <div className="space-y-1">
                    <h4 className="text-[10px] font-black text-white/40 uppercase tracking-widest mb-2 px-4">Marcas</h4>
                    {brandNames.map(brand => (
                        <button key={brand} onClick={() => {setSelectedBrand(brand); setSelectedCategory(null); setSelectedSeason(null); setIsMenuOpen(false); setView('catalog');}} className={`w-full text-left px-4 py-2 rounded-xl flex items-center justify-between text-[11px] font-bold uppercase transition-all ${selectedBrand === brand ? 'bg-white/20' : 'hover:bg-white/5'}`}>
                            {brand} <ChevronRight size={14} className="opacity-40"/>
                        </button>
                    ))}
                </div>
            </div>

            <div className="p-4 border-t border-white/10 bg-black/20 flex items-center justify-between">
                <button onClick={() => { setView('admin'); setIsMenuOpen(false); }} className={`p-2 rounded-xl transition-all ${view === 'admin' ? 'bg-white text-brand shadow-md' : 'hover:bg-white/10 text-white/70'}`} title={t('configuration')}>
                    <Settings size={20} />
                </button>
                
                <span className="text-[10px] text-white/40 font-black uppercase tracking-widest">Version 3.3.0</span>

                <button 
                  onClick={toggleDarkMode} 
                  className="p-2.5 rounded-xl hover:bg-white/10 text-white transition-all flex items-center justify-center"
                  title={theme.darkMode ? "Modo Claro" : "Modo Oscuro"}
                >
                    {theme.darkMode ? <Sun size={20} className="text-yellow-400" /> : <Moon size={20} />}
                </button>
            </div>
          </div>
        </div>
      )}

      <QuoteModal 
        isOpen={isQuoteModalOpen} 
        onClose={() => setIsQuoteModalOpen(false)} 
        cart={cart} 
        cartGroups={cartGroups} 
        total={cartTotal} 
        onUpdateQuantity={updateQuantity}
        onClearCart={() => setCart([])}
      />
      <CatalogPdfModal isOpen={isCatalogPdfOpen} onClose={() => setIsCatalogPdfOpen(false)} products={products} />
    </div>
  );
};

const App: React.FC = () => (
  <ThemeProvider>
    <SettingsProvider>
      <InnerApp />
    </SettingsProvider>
  </ThemeProvider>
);

export default App;
