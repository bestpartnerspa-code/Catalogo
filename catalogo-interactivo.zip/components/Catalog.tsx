
import React, { useState } from 'react';
import { Product, Brand } from '../types';
import ProductCard from './ProductCard';
import ProductModal from './ProductModal';
import { Search, FilterX, ArrowUpRight } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';
import { useSettings } from '../contexts/SettingsContext';

interface CatalogProps {
  products: Product[];
  allProducts: Product[];
  brands?: Brand[];
  isLoading: boolean;
  onAddToCart: (p: Product) => void;
  onUpdateQuantity: (p: Product, delta: number) => void;
  cart: Product[];
  activeCategory: string | null;
  onClearFilters: () => void;
}

const Catalog: React.FC<CatalogProps> = ({ 
  products, 
  allProducts,
  brands = [],
  isLoading, 
  onAddToCart,
  onUpdateQuantity,
  cart,
  activeCategory, 
  onClearFilters 
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const { theme } = useTheme();
  const { t } = useSettings();

  // Helper to get quantity
  const getProductQuantity = (id: string) => {
    return cart.filter(p => p.id === id).length;
  };

  // Helper to get brand logo
  const getBrandLogo = (brandName: string) => {
    return brands.find(b => b.name === brandName)?.image;
  };

  // Filter logic: Search Query AND Category
  const filteredProducts = products.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          p.sku.toLowerCase().includes(searchQuery.toLowerCase());
    // Note: ActiveCategory (which can be a category, brand or season) is handled by parent, 
    // but search is handled here locally or hybrid.
    // Since parent passes 'products' already filtered by Category/Brand/Season, we just filter by search.
    
    return matchesSearch;
  });

  return (
    <div className="flex flex-col h-full bg-white dark:bg-zinc-950 transition-colors">
      
      {/* Magazine Header Section */}
      <div className="relative overflow-hidden pt-8 pb-12 px-6 bg-gray-50 dark:bg-zinc-900/50 mb-8 rounded-b-[3rem]">
         {/* Decorative Blobs */}
         <div className="absolute top-0 right-0 w-64 h-64 bg-brand/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" style={{ backgroundColor: theme.colors.brand, opacity: 0.1 }}></div>
         <div className="absolute bottom-0 left-0 w-40 h-40 bg-blue-500/10 rounded-full blur-2xl translate-y-1/4 -translate-x-1/4"></div>

         <div className="relative z-10 max-w-5xl mx-auto flex flex-col md:flex-row md:items-end justify-between gap-6">
            <div>
               <div className="flex items-center gap-3 mb-2">
                  <span className="px-3 py-1 bg-black text-white dark:bg-white dark:text-black text-[10px] font-black uppercase tracking-widest rounded-full">
                    {theme.collectionYear || '2025'} Collection
                  </span>
                  <div className="h-px w-12 bg-gray-300"></div>
               </div>
               <h1 className="text-5xl md:text-7xl font-black uppercase tracking-tighter leading-[0.9] text-gray-900 dark:text-white">
                  {activeCategory ? activeCategory : (theme.appName || 'MEGA SALE')}
               </h1>
               <p className="mt-4 text-gray-500 dark:text-gray-400 font-medium max-w-sm leading-relaxed">
                  {theme.catalogTitle || t('catalogTitle')}
               </p>
            </div>

            {/* Search Bar stylized */}
            <div className="w-full md:w-auto min-w-[300px]">
                <div className="relative group">
                    <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                       <Search size={20} className="text-gray-400 group-focus-within:text-brand transition-colors" />
                    </div>
                    <input
                        type="text"
                        placeholder={t('searchPlaceholder')}
                        className="block w-full pl-12 pr-4 py-4 bg-white dark:bg-zinc-800 border-2 border-transparent focus:border-brand rounded-full shadow-xl shadow-gray-200/50 dark:shadow-none text-sm font-bold transition-all outline-none"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                    />
                    {activeCategory && (
                      <button onClick={onClearFilters} className="absolute inset-y-0 right-2 px-3 text-xs font-black text-red-500 uppercase flex items-center hover:bg-red-50 rounded-full transition-colors">
                        <FilterX size={14} className="mr-1"/> Clear
                      </button>
                    )}
                </div>
            </div>
         </div>
      </div>

      {isLoading ? (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2" style={{ borderColor: theme.colors.brand }}></div>
        </div>
      ) : (
        /* The Magazine Layout Grid */
        <div className="catalog-grid px-4 pb-32 max-w-7xl mx-auto w-full">
          {filteredProducts.map(product => (
            <div 
              key={product.id}
              role="button"
              tabIndex={0}
              onClick={() => setSelectedProduct(product)}
              className={`
                group relative cursor-pointer outline-none
                transition-all duration-300
                ${product.isFeatured ? 'col-span-2 row-span-2' : 'col-span-1 row-span-1'}
              `}
            >
              <ProductCard 
                product={product} 
                brandLogo={getBrandLogo(product.brand)} // Pass the brand logo
                onAddToCart={onAddToCart}
                onUpdateQuantity={onUpdateQuantity}
                quantity={getProductQuantity(product.id)}
                onClick={() => {}} 
              />
            </div>
          ))}
          {filteredProducts.length === 0 && (
            <div className="col-span-full flex flex-col items-center justify-center py-16 text-gray-500">
              <Search size={48} className="mb-4 opacity-20" />
              <p className="text-lg font-medium">{t('noProducts')}</p>
            </div>
          )}
        </div>
      )}

      {/* Product Detail Modal */}
      {selectedProduct && (
        <ProductModal 
          product={selectedProduct}
          allProducts={allProducts}
          brands={brands} // Pass brands here
          isOpen={!!selectedProduct}
          onClose={() => setSelectedProduct(null)}
          onSelectProduct={setSelectedProduct}
          onAddToCart={(p, qty) => {
            for (let i = 0; i < qty; i++) {
                onUpdateQuantity(p, 1);
            }
          }}
        />
      )}
    </div>
  );
};

export default Catalog;
