
import React from 'react';
import { useTheme } from '../contexts/ThemeContext';
import { useSettings } from '../contexts/SettingsContext';
import { ShoppingBag, Menu, Users, User } from 'lucide-react';

interface NavigationProps {
  isOnline: boolean;
  cartCount: number;
  onOpenMenu: () => void;
  onOpenCart: () => void;
}

const Navigation: React.FC<NavigationProps> = ({ 
  isOnline, 
  cartCount,
  onOpenMenu,
  onOpenCart
}) => {
  const { theme } = useTheme();
  const { t, customerType, setCustomerType } = useSettings();

  const toggleCustomerType = () => {
    setCustomerType(customerType === 'wholesale' ? 'retail' : 'wholesale');
  };

  return (
    /* Floating Navigation Container */
    <div className="fixed top-4 left-4 right-4 z-[60] flex justify-center pointer-events-none">
      <nav className="w-full max-w-7xl pointer-events-auto shadow-2xl rounded-2xl border border-white/20 backdrop-blur-md overflow-hidden transition-all duration-300"
           style={{ backgroundColor: theme.colors.brand, color: theme.colors.brandContrast }}>
        <div className="px-4 sm:px-6">
          <div className="flex items-center justify-between h-14 md:h-16">
            
            <div className="flex items-center">
              <button 
                onClick={onOpenMenu}
                className="p-2 rounded-xl hover:bg-white/10 mr-1 md:mr-2 active:bg-white/20 transition-colors"
                aria-label="Open Menu"
              >
                <Menu size={22} />
              </button>
              
              {theme.logoUrl ? (
                <img 
                  src={theme.logoUrl} 
                  alt="App Logo" 
                  className="h-7 md:h-9 object-contain"
                />
              ) : (
                <span className="text-lg md:text-xl font-black tracking-tighter truncate max-w-[120px] md:max-w-none uppercase">
                  {theme.appName || 'OmniCatalog'}
                </span>
              )}
            </div>

            <div className="flex items-center space-x-1 md:space-x-4">
              
              {/* Customer Type Toggler */}
              <button
                onClick={toggleCustomerType}
                className={`
                  hidden sm:flex items-center px-3 py-1.5 rounded-xl text-[10px] md:text-xs font-black border transition-all uppercase tracking-tighter
                  ${customerType === 'wholesale' ? 'bg-white/10 border-white/20' : 'bg-green-500 text-white border-transparent shadow-lg'}
                `}
              >
                {customerType === 'wholesale' ? <Users size={14} className="mr-1.5"/> : <User size={14} className="mr-1.5"/>}
                {customerType === 'wholesale' ? t('wholesale') : t('retail')}
              </button>

              {/* Cart Button */}
              <button 
                onClick={onOpenCart}
                className="relative p-2 rounded-xl hover:bg-white/10 active:bg-white/20 transition-all active:scale-90"
                aria-label="Open Cart"
              >
                <ShoppingBag size={22} />
                {cartCount > 0 && (
                  <span className="absolute -top-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full bg-white text-[10px] font-black leading-none text-gray-900 shadow-lg">
                    {cartCount}
                  </span>
                )}
              </button>
            </div>
          </div>
        </div>
      </nav>
    </div>
  );
};

export default Navigation;
