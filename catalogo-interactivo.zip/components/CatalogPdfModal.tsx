import React, { useState, useRef } from 'react';
import { Product } from '../types';
import { useTheme } from '../contexts/ThemeContext';
import { useSettings } from '../contexts/SettingsContext';
import { X, FileText, Loader2, Eye, EyeOff, Share2, Download } from 'lucide-react';
import ProductCard from './ProductCard';
// @ts-ignore
import { jsPDF } from 'jspdf';
// @ts-ignore
import html2canvas from 'html2canvas';

interface CatalogPdfModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
}

const CatalogPdfModal: React.FC<CatalogPdfModalProps> = ({ isOpen, onClose, products }) => {
  const { theme } = useTheme();
  const { t, formatPrice, getDisplayPrice } = useSettings();
  const [isGenerating, setIsGenerating] = useState(false);
  const [progress, setProgress] = useState(0);
  
  // Ref for the hidden container used for generation
  const printContainerRef = useRef<HTMLDivElement>(null);

  if (!isOpen) return null;

  // Helper to chunk products into pages (e.g., 6 products per A4 page)
  const chunkArray = (arr: Product[], size: number) => {
    return Array.from({ length: Math.ceil(arr.length / size) }, (v, i) =>
      arr.slice(i * size, i * size + size)
    );
  };

  const generatePDF = async (includePrices: boolean) => {
    if (!printContainerRef.current) return;
    
    setIsGenerating(true);
    setProgress(0);

    try {
      // 1. Setup PDF
      const pdf = new jsPDF('p', 'mm', 'a4');
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = pdf.internal.pageSize.getHeight();
      
      // Items per page
      const itemsPerPage = 6; 
      const chunks = chunkArray(products, itemsPerPage);
      const totalPages = chunks.length;

      // 2. Render and Capture Pages
      for (let i = 0; i < totalPages; i++) {
        setProgress(Math.round(((i) / totalPages) * 100));

        // Render the current chunk into the DOM
        const pageProducts = chunks[i];
        
        // Use a Promise to allow React to render the DOM update before capturing
        await new Promise<void>((resolve) => {
           // We manipulate the hidden container directly via React for simplicity in this logic block, 
           // but normally we'd use state. Here we are inside an async handler, so we need to trigger a render 
           // or use a separate "PrintComponent". 
           // To keep it simple and robust without complex state effects:
           // We will render the components manually into the HTML string or use a specific technique.
           // BETTER APPROACH: We rely on the `HiddenPrintLayout` component below which renders *all* items,
           // but we hide/show pages via CSS or capture specific coordinates.
           // Even better for performance: Render one page at a time using a state variable.
           setPageToRender({ index: i, items: pageProducts, includePrices, totalPages });
           setTimeout(resolve, 250); // Wait for images to load/render
        });

        const element = printContainerRef.current;
        if (!element) continue;

        // Capture
        const canvas = await html2canvas(element, {
          scale: 2, // High resolution
          useCORS: true, // Allow cross-origin images
          logging: false,
          backgroundColor: theme.darkMode ? '#1e1e1e' : '#f3f4f6'
        });

        const imgData = canvas.toDataURL('image/jpeg', 0.8);
        
        // Add to PDF
        if (i > 0) pdf.addPage();
        pdf.addImage(imgData, 'JPEG', 0, 0, pdfWidth, pdfHeight);
      }

      setProgress(100);

      // 3. Output and Share
      const fileName = `Catalogo_${(theme.appName || 'App').replace(/\s+/g, '_')}.pdf`;
      const pdfBlob = pdf.output('blob');
      const file = new File([pdfBlob], fileName, { type: 'application/pdf' });

      if (navigator.canShare && navigator.canShare({ files: [file] })) {
        await navigator.share({
          files: [file],
          title: 'Catálogo de Productos',
          text: `Adjunto el catálogo de ${theme.appName || 'nuestra tienda'}.`,
        });
      } else {
        pdf.save(fileName);
        alert("PDF Descargado exitosamente.");
      }
      
      onClose();

    } catch (e) {
      console.error("PDF Error", e);
      alert("Error generando el PDF. Intenta con menos productos o verifica las imágenes.");
    } finally {
      setIsGenerating(false);
      setPageToRender(null); // Cleanup
    }
  };

  // State to control what is currently rendered in the hidden div
  const [pageToRender, setPageToRender] = useState<{ index: number; items: Product[]; includePrices: boolean; totalPages: number } | null>(null);

  return (
    <div className="fixed inset-0 z-[110] flex items-center justify-center p-4">
      <div 
        className="absolute inset-0 bg-black/60 backdrop-blur-sm transition-opacity" 
        onClick={!isGenerating ? onClose : undefined}
      />

      {/* Main Dialog */}
      <div className="relative bg-white dark:bg-zinc-900 rounded-xl shadow-2xl w-full max-w-md overflow-hidden animate-in fade-in zoom-in duration-200 border border-white/10">
        <div className="p-6">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-xl font-bold text-gray-800 dark:text-white flex items-center">
              <FileText className="mr-2 text-brand" />
              {t('shareOptions')}
            </h3>
            {!isGenerating && (
                <button onClick={onClose} className="p-1 hover:bg-gray-100 dark:hover:bg-zinc-800 rounded-full">
                <X size={20} className="text-gray-500" />
                </button>
            )}
          </div>

          <p className="text-gray-600 dark:text-gray-400 mb-6 text-sm">
             {t('generateCatalog')} ({products.length} {t('item')}s).
             <br/>
             <span className="text-xs opacity-70">Formato: A4 Alta Calidad (Idéntico a la App)</span>
          </p>

          {isGenerating ? (
            <div className="flex flex-col items-center justify-center py-8">
                <Loader2 size={48} className="animate-spin text-brand mb-4" />
                <p className="font-bold text-gray-700 dark:text-gray-200">{t('preparingPdf')}</p>
                <div className="w-full bg-gray-200 dark:bg-zinc-700 rounded-full h-2.5 mt-4">
                    <div className="bg-brand h-2.5 rounded-full transition-all duration-300" style={{ width: `${progress}%`, backgroundColor: theme.colors.brand }}></div>
                </div>
                <p className="text-xs text-gray-500 mt-2">Página {pageToRender ? pageToRender.index + 1 : 0} de {pageToRender?.totalPages || '...'}</p>
            </div>
          ) : (
            <div className="space-y-3">
              <button 
                onClick={() => generatePDF(true)}
                className="w-full py-4 px-4 bg-brand text-white rounded-xl font-black text-sm uppercase tracking-widest shadow-lg hover:opacity-90 flex items-center justify-center transition-all active:scale-95"
              >
                <Eye size={20} className="mr-2" />
                Con Precios (Estándar)
              </button>

              <button 
                onClick={() => generatePDF(false)}
                className="w-full py-4 px-4 bg-gray-100 dark:bg-zinc-800 text-gray-700 dark:text-gray-300 rounded-xl font-black text-sm uppercase tracking-widest hover:bg-gray-200 dark:hover:bg-zinc-700 flex items-center justify-center transition-all"
              >
                <EyeOff size={20} className="mr-2" />
                Sin Precios (Presentación)
              </button>
            </div>
          )}
        </div>
      </div>

      {/* 
        HIDDEN PRINT CONTAINER 
        This is what html2canvas captures. It mimics an A4 page.
        Width: 794px (approx A4 at 96 DPI). Height: 1123px.
        We scale this up during capture for better quality.
      */}
      {pageToRender && (
        <div 
           ref={printContainerRef}
           style={{
             position: 'fixed',
             top: 0,
             left: '-9999px', // Hide from view
             width: '794px',
             minHeight: '1123px', // A4 Height
             backgroundColor: theme.darkMode ? '#111' : '#f3f4f6', // Match app background
             zIndex: -50,
             padding: '40px',
             boxSizing: 'border-box',
             fontFamily: theme.typography.fontFamily
           }}
        >
           {/* PDF HEADER */}
           <div className="flex items-center justify-between mb-8 border-b-4 pb-4" style={{ borderColor: theme.colors.brand }}>
              <div className="flex items-center gap-4">
                  {theme.logoUrl ? (
                      <img src={theme.logoUrl} className="h-16 w-auto object-contain" />
                  ) : (
                      <div className="bg-brand text-white p-3 rounded-lg">
                          <FileText size={32} />
                      </div>
                  )}
                  <div>
                      <h1 className="text-3xl font-black uppercase tracking-tighter" style={{ color: theme.colors.text }}>{theme.appName || 'CATÁLOGO'}</h1>
                      <p className="text-sm font-bold text-gray-400 uppercase tracking-widest">
                          {pageToRender.includePrices ? 'Lista de Precios Oficial' : 'Portafolio de Productos'}
                      </p>
                  </div>
              </div>
              <div className="text-right">
                   <div className="text-xs font-black bg-black text-white px-3 py-1 rounded-full uppercase inline-block mb-1">
                       Pág {pageToRender.index + 1} / {pageToRender.totalPages}
                   </div>
                   <p className="text-xs text-gray-400 font-medium">{new Date().toLocaleDateString()}</p>
              </div>
           </div>

           {/* PDF GRID */}
           <div className="grid grid-cols-2 gap-6">
              {pageToRender.items.map((p) => (
                  <div key={p.id} className="relative block h-[320px]">
                      {/* Render ProductCard with a customized wrapper to strip buttons via CSS overlay or structure */}
                      <div className="h-full transform scale-100 pointer-events-none">
                         {/* We temporarily override theme.showPrices for the card context via a prop wrapper if needed, 
                             but here we rely on the component. If prices are off in modal request, we mask them. */}
                         <div className={!pageToRender.includePrices ? "price-hidden" : ""}>
                             <ProductCard 
                                product={p}
                                brandLogo={undefined} // Or pass brand logo if available
                                onAddToCart={() => {}}
                                onUpdateQuantity={() => {}}
                                quantity={0}
                                onClick={() => {}}
                             />
                         </div>
                      </div>
                      
                      {/* OVERLAY TO HIDE BUTTONS FOR PRINT */}
                      {/* We cover the bottom action area with a clean brand tag or whitespace */}
                      <div className="absolute bottom-4 left-4 right-4 h-12 flex items-center justify-center bg-white dark:bg-zinc-800 rounded-2xl border border-gray-100 dark:border-zinc-700 shadow-sm z-50">
                          {pageToRender.includePrices ? (
                             <span className="text-xl font-black text-brand">{getDisplayPrice(p.price) ? formatPrice(getDisplayPrice(p.price)) : ''}</span>
                          ) : (
                             <span className="text-xs font-black text-gray-400 uppercase tracking-widest">Disponible</span>
                          )}
                      </div>
                  </div>
              ))}
           </div>

           {/* PDF FOOTER */}
           <div className="absolute bottom-6 left-0 right-0 text-center">
               <p className="text-[10px] text-gray-400 font-medium uppercase tracking-widest">Generado vía App {theme.appName}</p>
           </div>

           {/* CSS to hide original price badge if we want to override it, or other adjustments */}
           <style>{`
             .price-hidden .price-badge { display: none !important; }
           `}</style>
        </div>
      )}
    </div>
  );
};

export default CatalogPdfModal;