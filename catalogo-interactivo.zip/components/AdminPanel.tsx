
import React, { useState, useEffect } from 'react';
import { 
  Trash2, X, Plus, Edit2, Loader2, Save, Search, Menu, 
  ChevronRight, Palette, Layout, Globe, 
  Download, Image as ImageIcon, Smartphone, 
  ShieldCheck, Database, RefreshCw,
  ArrowLeft, ArrowRight, Upload, Layers, Tag, Briefcase, Share2
} from 'lucide-react';
import { dbService } from '../services/db';
import { backupService } from '../services/backupService';
import { Product, ThemeConfig, Brand, Category, ShareButtonConfig } from '../types';
import { useTheme } from '../contexts/ThemeContext';
import CachedImage from './CachedImage';

interface AdminPanelProps {
  onBack?: () => void;
}

const AdminPanel: React.FC<AdminPanelProps> = ({ onBack }) => {
  const { theme, setTheme } = useTheme();
  const [viewMode, setViewMode] = useState<'inventory' | 'masters' | 'appearance' | 'settings'>('inventory');
  
  const [products, setProducts] = useState<Product[]>([]);
  const [brands, setBrands] = useState<Brand[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  
  const [isEditingProduct, setIsEditingProduct] = useState(false);
  const [editingProduct, setEditingProduct] = useState<any>({}); 
  
  const [isEditingBrand, setIsEditingBrand] = useState(false);
  const [editingBrand, setEditingBrand] = useState<any>({});

  const [isEditingCategory, setIsEditingCategory] = useState(false);
  const [editingCategory, setEditingCategory] = useState<any>({});

  const [isSaving, setIsSaving] = useState(false); 

  // Search and Pagination
  const [inventorySearch, setInventorySearch] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 6;

  // Appearance/Settings Local State (Draft)
  const [tempTheme, setTempTheme] = useState<ThemeConfig>(theme);
  const [isSavingDesign, setIsSavingDesign] = useState(false);

  // Backup/Restore states
  const [isBackingUp, setIsBackingUp] = useState(false);
  const [restoreFile, setRestoreFile] = useState<File | null>(null);

  const loadData = async () => {
    const [p, b, c] = await Promise.all([
      dbService.getAllProducts(),
      dbService.getBrands(),
      dbService.getCategories()
    ]);
    setProducts(p);
    setBrands(b);
    setCategories(c);
  };

  useEffect(() => { 
    loadData(); 
    setTempTheme(theme);
  }, [theme]);

  const handleSaveTheme = async () => {
    setIsSavingDesign(true);
    try {
      await setTheme(tempTheme);
      alert("¡Configuración actualizada y guardada!");
    } catch (e) {
      alert("Error al persistir los cambios.");
    } finally {
      setIsSavingDesign(false);
    }
  };

  const updateTempTheme = (path: string, value: any) => {
    const updated = JSON.parse(JSON.stringify(tempTheme));
    const keys = path.split('.');
    let current: any = updated;
    for (let i = 0; i < keys.length - 1; i++) {
      current = current[keys[i]];
    }
    current[keys[keys.length - 1]] = value;
    setTempTheme(updated);
  };

  const handleSaveProduct = async () => {
    if (isSaving) return; 
    setIsSaving(true);
    try {
        const productToSave = {
            ...editingProduct, 
            id: editingProduct.id || Date.now().toString(), 
            price: Number(editingProduct.price) || 0,
            originalPrice: Number(editingProduct.originalPrice) || 0,
            stock: Number(editingProduct.stock) || 0,
            unitsPerDisplay: Number(editingProduct.unitsPerDisplay) || 1,
            priceScales: editingProduct.priceScales || [],
            lastUpdated: Date.now()
        } as Product;
        await dbService.bulkPutProducts([productToSave]); 
        await loadData(); 
        setIsEditingProduct(false); 
        window.dispatchEvent(new Event('catalogUpdated'));
    } catch (err) {
        console.error(err);
    } finally {
        setIsSaving(false);
    }
  };

  const handleSaveBrand = async () => {
    try {
      const b = { ...editingBrand, id: editingBrand.id || Date.now().toString() };
      await dbService.saveBrand(b);
      await loadData();
      setIsEditingBrand(false);
    } catch (e) { console.error(e); }
  };

  const handleSaveCategory = async () => {
    try {
      const c = { ...editingCategory, id: editingCategory.id || Date.now().toString() };
      await dbService.saveCategory(c);
      await loadData();
      setIsEditingCategory(false);
    } catch (e) { console.error(e); }
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>, target: 'product' | 'brand' | 'share' | 'logo' = 'product', extraId?: string) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const uniqueId = `local_${target}_${Date.now()}_${file.name.replace(/[^a-zA-Z0-9.]/g, '')}`;
    try {
      await dbService.saveCachedImage(uniqueId, file);
      if (target === 'product') {
        setEditingProduct({ ...editingProduct, image: uniqueId });
      } else if (target === 'brand') {
        setEditingBrand({ ...editingBrand, image: uniqueId });
      } else if (target === 'logo') {
        updateTempTheme('logoUrl', uniqueId);
      } else if (target === 'share' && extraId) {
        const newButtons = (tempTheme.shareButtons || []).map(b => 
            b.id === extraId ? { ...b, url: uniqueId } : b
        );
        updateTempTheme('shareButtons', newButtons);
      }
    } catch (error) {
      alert("Error al guardar la imagen localmente.");
    }
  };

  const addShareButton = () => {
    const newBtn: ShareButtonConfig = { id: Date.now().toString(), label: 'Nuevo Botón', url: '' };
    updateTempTheme('shareButtons', [...(tempTheme.shareButtons || []), newBtn]);
  };

  const removeShareButton = (id: string) => {
    const newButtons = (tempTheme.shareButtons || []).filter(b => b.id !== id);
    updateTempTheme('shareButtons', newButtons);
  };

  const updateShareButton = (id: string, label: string) => {
    const newButtons = (tempTheme.shareButtons || []).map(b => 
        b.id === id ? { ...b, label } : b
    );
    updateTempTheme('shareButtons', newButtons);
  };

  const addPriceScale = () => {
    const scales = [...(editingProduct.priceScales || [])];
    scales.push({ minQuantity: 0, price: 0 });
    setEditingProduct({ ...editingProduct, priceScales: scales });
  };

  const removePriceScale = (index: number) => {
    const scales = [...(editingProduct.priceScales || [])];
    scales.splice(index, 1);
    setEditingProduct({ ...editingProduct, priceScales: scales });
  };

  const updatePriceScale = (index: number, field: string, value: number) => {
    const scales = [...(editingProduct.priceScales || [])];
    scales[index] = { ...scales[index], [field]: value };
    setEditingProduct({ ...editingProduct, priceScales: scales });
  };

  const filteredProducts = products.filter(p => 
    p.name.toLowerCase().includes(inventorySearch.toLowerCase()) || 
    p.sku.toLowerCase().includes(inventorySearch.toLowerCase())
  );

  const paginatedProducts = filteredProducts.slice(
    (currentPage - 1) * itemsPerPage, 
    currentPage * itemsPerPage
  );

  const inputClass = `w-full border rounded-xl px-4 py-3 ${theme.darkMode ? 'bg-zinc-800 border-zinc-700 text-white' : 'bg-white border-gray-100 text-gray-900'} focus:ring-2 focus:ring-brand outline-none transition-all shadow-sm text-sm font-bold`;
  const labelClass = "block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2 px-1";

  // Common seasons list
  const COMMON_SEASONS = ['Todo el año', 'Verano', 'Otoño', 'Invierno', 'Primavera', 'Navidad', 'Escolar', 'Fiestas Patrias', 'Halloween'];

  return (
    <div className={`fixed inset-0 z-[100] flex flex-col ${theme.darkMode ? 'bg-zinc-950' : 'bg-[#f8fafc]'}`}>
      
      {/* HEADER SYNCED WITH CATALOG NAVIGATION STYLE */}
      <div className="pt-6 px-4 pb-2">
        <nav className="w-full max-w-7xl mx-auto shadow-2xl rounded-2xl border border-white/20 backdrop-blur-md overflow-hidden transition-all duration-300"
             style={{ backgroundColor: theme.colors.brand, color: theme.colors.brandContrast }}>
          <div className="px-4 sm:px-6">
            <div className="flex items-center justify-between h-14 md:h-16">
              <div className="flex items-center">
                <button onClick={onBack} className="p-2 rounded-xl hover:bg-white/10 mr-1 md:mr-2 active:bg-white/20 transition-colors">
                  <Menu size={22} />
                </button>
                <span className="text-lg md:text-xl font-black tracking-tighter truncate uppercase">
                  {theme.appName || 'OmniCatalog'} <span className="opacity-50 ml-2 text-xs">ADMIN</span>
                </span>
              </div>
              <div className="flex items-center gap-2">
                 <button onClick={onBack} className="text-[10px] font-black uppercase tracking-widest bg-white/10 px-4 py-2 rounded-xl border border-white/20">Cerrar</button>
              </div>
            </div>
          </div>
        </nav>
      </div>

      {/* TABS SELECTOR - PILL STYLE */}
      <div className="px-5 py-4">
        <div className="bg-gray-200/50 dark:bg-zinc-800/50 p-1.5 rounded-[22px] flex gap-1 max-w-2xl mx-auto shadow-inner border border-gray-200/50 dark:border-zinc-700/50">
          <button onClick={() => setViewMode('inventory')} className={`flex-1 py-3 rounded-[18px] text-[10px] font-black uppercase tracking-widest transition-all ${viewMode === 'inventory' ? 'bg-white dark:bg-zinc-700 text-gray-900 dark:text-white shadow-md' : 'text-gray-400'}`}>Productos</button>
          <button onClick={() => setViewMode('masters')} className={`flex-1 py-3 rounded-[18px] text-[10px] font-black uppercase tracking-widest transition-all ${viewMode === 'masters' ? 'bg-white dark:bg-zinc-700 text-gray-900 dark:text-white shadow-md' : 'text-gray-400'}`}>Listas</button>
          <button onClick={() => setViewMode('appearance')} className={`flex-1 py-3 rounded-[18px] text-[10px] font-black uppercase tracking-widest transition-all ${viewMode === 'appearance' ? 'bg-white dark:bg-zinc-700 text-gray-900 dark:text-white shadow-md' : 'text-gray-400'}`}>Diseño</button>
          <button onClick={() => setViewMode('settings')} className={`flex-1 py-3 rounded-[18px] text-[10px] font-black uppercase tracking-widest transition-all ${viewMode === 'settings' ? 'bg-white dark:bg-zinc-700 text-gray-900 dark:text-white shadow-md' : 'text-gray-400'}`}>Sistema</button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-6 pb-24 no-scrollbar">
        
        {/* 1. INVENTORY VIEW */}
        {viewMode === 'inventory' && !isEditingProduct && (
          <div className="max-w-4xl mx-auto space-y-6 animate-in fade-in slide-in-from-bottom-4">
            <div className="flex gap-3">
              <div className="flex-1 relative group">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
                <input 
                  type="text" 
                  placeholder="Buscar producto..." 
                  value={inventorySearch}
                  onChange={e => setInventorySearch(e.target.value)}
                  className="w-full bg-white dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800 rounded-[18px] py-4 pl-12 pr-4 shadow-sm text-sm font-semibold focus:ring-2 focus:ring-brand outline-none"
                />
              </div>
              <button 
                onClick={() => { setEditingProduct({ unitsPerDisplay: 1, stock: 0, priceScales: [], season: 'Todo el año' }); setIsEditingProduct(true); }}
                className="bg-brand text-white w-14 h-14 rounded-[18px] shadow-xl flex items-center justify-center active:scale-95 transition-all"
                style={{ backgroundColor: theme.colors.brand }}
              >
                <Plus size={28} strokeWidth={3} />
              </button>
            </div>

            <div className="bg-white dark:bg-zinc-900 rounded-[28px] overflow-hidden shadow-sm border border-gray-50 dark:border-zinc-800">
              <div className="px-6 py-4 border-b dark:border-zinc-800 flex justify-between text-[10px] font-black uppercase text-gray-400 tracking-widest bg-gray-50/50 dark:bg-zinc-900">
                <span className="w-14">Img</span>
                <span className="flex-1 ml-4">Detalles</span>
                <span className="w-20 text-right">Acciones</span>
              </div>
              <div className="divide-y divide-gray-50 dark:divide-zinc-800">
                {paginatedProducts.map(p => (
                  <div key={p.id} className="p-4 flex items-center gap-4 hover:bg-gray-50/50 dark:hover:bg-zinc-800/30 transition-colors">
                    <CachedImage src={p.image} className="w-16 h-16 rounded-[16px] object-cover shadow-sm bg-gray-100" />
                    <div className="flex-1 min-w-0">
                      <h4 className="font-black text-sm uppercase truncate text-gray-900 dark:text-white mb-1">{p.name}</h4>
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-bold text-gray-400">${p.price.toLocaleString()}</span>
                        {p.season && <span className="px-2 py-0.5 rounded-lg text-[9px] font-black uppercase bg-blue-50 text-blue-600">{p.season}</span>}
                      </div>
                    </div>
                    <div className="flex items-center gap-1">
                      <button onClick={() => { setEditingProduct(p); setIsEditingProduct(true); }} className="p-2.5 text-blue-500 hover:bg-blue-50 rounded-xl"><Edit2 size={18}/></button>
                      <button onClick={async () => { if(confirm('¿Eliminar?')) { await dbService.deleteProduct(p.id); loadData(); }}} className="p-2.5 text-red-500 hover:bg-red-50 rounded-xl"><Trash2 size={18}/></button>
                    </div>
                  </div>
                ))}
              </div>
              <div className="p-6 border-t dark:border-zinc-800 flex items-center justify-between">
                <span className="text-[10px] font-bold text-gray-400">{paginatedProducts.length} de {filteredProducts.length}</span>
                <div className="flex gap-2">
                   <button onClick={() => setCurrentPage(p => Math.max(1, p-1))} className="w-9 h-9 rounded-xl border flex items-center justify-center text-gray-400"><ArrowLeft size={16}/></button>
                   <button className="w-9 h-9 rounded-xl bg-brand text-white text-xs font-black shadow-lg" style={{ backgroundColor: theme.colors.brand }}>{currentPage}</button>
                   <button onClick={() => setCurrentPage(p => Math.min(Math.ceil(filteredProducts.length/itemsPerPage), p+1))} className="w-9 h-9 rounded-xl border flex items-center justify-center text-gray-400"><ArrowRight size={16}/></button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 2. MASTER LISTS VIEW */}
        {viewMode === 'masters' && (
          <div className="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-8 animate-in fade-in slide-in-from-bottom-4">
             {/* Brands Card */}
             <div className="bg-white dark:bg-zinc-900 p-6 rounded-[28px] shadow-sm border border-gray-100 dark:border-zinc-800">
                <div className="flex items-center justify-between mb-6">
                   <h3 className="flex items-center gap-2 font-black uppercase text-[10px] text-gray-400 tracking-widest"><Briefcase size={14}/> Marcas</h3>
                   <button onClick={() => { setEditingBrand({}); setIsEditingBrand(true); }} className="w-8 h-8 bg-brand text-white rounded-lg flex items-center justify-center shadow-lg" style={{ backgroundColor: theme.colors.brand }}><Plus size={18}/></button>
                </div>
                <div className="space-y-3">
                   {brands.map(b => (
                      <div key={b.id} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-zinc-800 rounded-2xl border border-gray-100 dark:border-zinc-700">
                         <div className="flex items-center gap-3">
                            <CachedImage src={b.image} className="w-10 h-10 rounded-lg bg-white object-contain border" />
                            <span className="text-xs font-black uppercase text-gray-700 dark:text-gray-300">{b.name}</span>
                         </div>
                         <div className="flex gap-1">
                            <button onClick={() => { setEditingBrand(b); setIsEditingBrand(true); }} className="p-2 text-blue-500"><Edit2 size={16}/></button>
                            <button onClick={async () => { if(confirm('¿Borrar marca?')) { await dbService.deleteBrand(b.id); loadData(); }}} className="p-2 text-red-500"><Trash2 size={16}/></button>
                         </div>
                      </div>
                   ))}
                </div>
             </div>

             {/* Categories Card */}
             <div className="bg-white dark:bg-zinc-900 p-6 rounded-[28px] shadow-sm border border-gray-100 dark:border-zinc-800">
                <div className="flex items-center justify-between mb-6">
                   <h3 className="flex items-center gap-2 font-black uppercase text-[10px] text-gray-400 tracking-widest"><Layers size={14}/> Categorías</h3>
                   <button onClick={() => { setEditingCategory({}); setIsEditingCategory(true); }} className="w-8 h-8 bg-brand text-white rounded-lg flex items-center justify-center shadow-lg" style={{ backgroundColor: theme.colors.brand }}><Plus size={18}/></button>
                </div>
                <div className="space-y-3">
                   {categories.map(c => (
                      <div key={c.id} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-zinc-800 rounded-2xl border border-gray-100 dark:border-zinc-700">
                         <span className="text-xs font-black uppercase text-gray-700 dark:text-gray-300">{c.name}</span>
                         <div className="flex gap-1">
                            <button onClick={() => { setEditingCategory(c); setIsEditingCategory(true); }} className="p-2 text-blue-500"><Edit2 size={16}/></button>
                            <button onClick={async () => { if(confirm('¿Borrar categoría?')) { await dbService.deleteCategory(c.id); loadData(); }}} className="p-2 text-red-500"><Trash2 size={16}/></button>
                         </div>
                      </div>
                   ))}
                </div>
             </div>
          </div>
        )}

        {/* 3. APPEARANCE VIEW */}
        {viewMode === 'appearance' && (
          <div className="max-w-4xl mx-auto space-y-6 animate-in fade-in slide-in-from-bottom-4">
             <div className="bg-white dark:bg-zinc-900 p-8 rounded-[28px] shadow-sm border border-gray-100 dark:border-zinc-800">
                <h3 className="flex items-center gap-2 font-black uppercase text-[10px] mb-6 text-gray-400 tracking-widest"><Smartphone size={14}/> Identidad Visual</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className={labelClass}>Nombre App (Negocio)</label>
                    <input type="text" value={tempTheme.appName} onChange={e => updateTempTheme('appName', e.target.value)} className={inputClass} />
                  </div>
                  <div>
                    <label className={labelClass}>Subtítulo / Slogan Catálogo</label>
                    <input type="text" value={tempTheme.catalogTitle || ''} onChange={e => updateTempTheme('catalogTitle', e.target.value)} className={inputClass} placeholder="Ej: Las mejores ofertas..." />
                  </div>
                  <div>
                    <label className={labelClass}>Año / Fecha de Colección</label>
                    <input type="text" value={tempTheme.collectionYear || ''} onChange={e => updateTempTheme('collectionYear', e.target.value)} className={inputClass} placeholder="Ej: 2025" />
                  </div>
                  <div>
                      <label className={labelClass}>Logo Principal</label>
                      <div className="flex gap-2">
                          <input type="text" className={inputClass} value={tempTheme.logoUrl || ''} onChange={e => updateTempTheme('logoUrl', e.target.value)} placeholder="URL..." />
                          <label className="bg-gray-100 p-3 rounded-xl cursor-pointer flex items-center justify-center"><input type="file" accept="image/*" className="hidden" onChange={(e) => handleImageUpload(e, 'logo')} /><Upload size={20}/></label>
                      </div>
                  </div>
                  <div>
                    <label className={labelClass}>Modo Oscuro</label>
                    <button onClick={() => updateTempTheme('darkMode', !tempTheme.darkMode)} className={`w-full py-3 rounded-xl font-black text-xs uppercase tracking-widest transition-all ${tempTheme.darkMode ? 'bg-zinc-800 text-white' : 'bg-gray-100 text-gray-600'}`}>
                       {tempTheme.darkMode ? 'Desactivar' : 'Activar'}
                    </button>
                  </div>
                  <div>
                    <label className={labelClass}>Color Marca</label>
                    <input type="color" className="w-full h-12 rounded-xl" value={tempTheme.colors.brand} onChange={e => updateTempTheme('colors.brand', e.target.value)} />
                  </div>
                </div>
             </div>
             <button onClick={handleSaveTheme} className="w-full bg-brand text-white py-5 rounded-[22px] font-black text-xs uppercase tracking-widest shadow-xl flex items-center justify-center gap-2 active:scale-95 transition-all" style={{ backgroundColor: theme.colors.brand }}>
                {isSavingDesign ? <Loader2 size={18} className="animate-spin" /> : <Save size={18}/>} Guardar Cambios
             </button>
          </div>
        )}

        {/* 4. SETTINGS VIEW (SYSTEM) */}
        {viewMode === 'settings' && (
          <div className="max-w-4xl mx-auto space-y-6 animate-in fade-in slide-in-from-bottom-4">
             <div className="bg-white dark:bg-zinc-900 p-8 rounded-[28px] shadow-sm border border-gray-100 dark:border-zinc-800">
                <div className="flex items-center justify-between mb-6">
                   <h3 className="flex items-center gap-2 font-black uppercase text-[10px] text-gray-400 tracking-widest"><Share2 size={14}/> Botones de Compartir</h3>
                   <button onClick={addShareButton} className="bg-brand text-white px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest flex items-center gap-2 shadow-lg" style={{ backgroundColor: theme.colors.brand }}><Plus size={14}/> Añadir Botón</button>
                </div>
                
                <div className="space-y-4">
                   {(tempTheme.shareButtons || []).map((btn) => (
                      <div key={btn.id} className="p-5 bg-gray-50 dark:bg-zinc-800/50 rounded-2xl border border-gray-100 dark:border-zinc-800 flex flex-col sm:flex-row gap-4">
                         <div className="flex-1">
                            <label className={labelClass}>Etiqueta (Ej: WhatsApp)</label>
                            <input type="text" className={inputClass} value={btn.label} onChange={e => updateShareButton(btn.id, e.target.value)} />
                         </div>
                         <div className="flex-1">
                            <label className={labelClass}>Imagen a Compartir</label>
                            <div className="flex gap-2">
                               <input type="text" className={inputClass} value={btn.url} readOnly placeholder="ID de Imagen..." />
                               <label className="bg-white dark:bg-zinc-800 p-3 rounded-xl cursor-pointer border shadow-sm flex items-center justify-center"><input type="file" accept="image/*" className="hidden" onChange={(e) => handleImageUpload(e, 'share', btn.id)} /><Upload size={18}/></label>
                            </div>
                         </div>
                         <div className="flex items-end">
                            <button onClick={() => removeShareButton(btn.id)} className="p-3.5 text-red-500 bg-red-50 dark:bg-red-900/10 rounded-xl"><Trash2 size={20}/></button>
                         </div>
                      </div>
                   ))}
                </div>
             </div>

             <div className="bg-white dark:bg-zinc-900 p-8 rounded-[28px] shadow-sm border border-gray-100 dark:border-zinc-800">
                <h3 className="flex items-center gap-2 font-black uppercase text-[10px] mb-6 text-gray-400 tracking-widest"><Globe size={14}/> Sistema y Datos</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                   <button onClick={async () => {
                        setIsBackingUp(true);
                        const blob = await backupService.createBackup();
                        const url = URL.createObjectURL(blob);
                        const a = document.createElement('a');
                        a.href = url;
                        a.download = `Backup_${theme.appName}_${new Date().toISOString().split('T')[0]}.json`;
                        a.click();
                        setIsBackingUp(false);
                      }} className="py-5 bg-emerald-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl flex items-center justify-center gap-2">
                        {isBackingUp ? <Loader2 className="animate-spin" size={18}/> : <Download size={18}/>} Descargar Backup
                   </button>
                   <label className="py-5 bg-white dark:bg-zinc-800 border-2 border-dashed border-emerald-200 text-emerald-700 dark:text-emerald-400 rounded-2xl font-black text-xs uppercase text-center cursor-pointer shadow-sm flex items-center justify-center">
                         Restaurar Backup
                         <input type="file" onChange={e => setRestoreFile(e.target.files?.[0] || null)} className="hidden" />
                   </label>
                </div>
                {restoreFile && (
                  <div className="mt-4 bg-emerald-50 dark:bg-emerald-900/10 p-4 rounded-xl flex items-center justify-between border border-emerald-100">
                    <span className="text-xs font-black text-emerald-800 truncate">{restoreFile.name}</span>
                    <button onClick={async () => { if(confirm('¿Restaurar?')){ await backupService.restoreBackup(restoreFile); window.location.reload(); }}} className="bg-emerald-600 text-white px-6 py-2 rounded-lg text-[10px] font-black uppercase">Aplicar Ahora</button>
                  </div>
                )}
             </div>

             <button onClick={handleSaveTheme} className="w-full bg-brand text-white py-5 rounded-[22px] font-black text-xs uppercase tracking-widest shadow-xl flex items-center justify-center gap-2 active:scale-95 transition-all" style={{ backgroundColor: theme.colors.brand }}>
                {isSavingDesign ? <Loader2 size={18} className="animate-spin" /> : <Save size={18}/>} Guardar Configuración Sistema
             </button>

             <div className="bg-red-50 dark:bg-red-900/10 p-8 rounded-[28px] border border-red-100 dark:border-red-800/30">
                <h3 className="flex items-center gap-2 font-black uppercase text-[10px] mb-6 text-red-800 dark:text-red-400 tracking-widest"><Trash2 size={14}/> Zona de Peligro</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                   <button onClick={async () => { if(confirm('¿Borrar todo?')){ await dbService.clearCatalog(); loadData(); }}} className="py-4 bg-white dark:bg-zinc-800 border border-red-200 text-red-600 rounded-2xl font-black text-[10px] uppercase shadow-sm">Limpiar Inventario</button>
                   <button onClick={() => { if(confirm('¿Resetear?')){ localStorage.clear(); window.location.reload(); }}} className="py-4 bg-red-600 text-white rounded-2xl font-black text-[10px] uppercase shadow-lg">Resetear Fábrica</button>
                </div>
             </div>
          </div>
        )}

        {/* MODAL: PRODUCT EDITOR (WITH VOLUME DISCOUNTS & BRANDS) */}
        {isEditingProduct && (
          <div className="fixed inset-0 z-[150] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <div className="bg-white dark:bg-zinc-900 rounded-[28px] p-8 shadow-2xl border border-gray-100 dark:border-zinc-800 w-full max-w-3xl max-h-[90vh] overflow-y-auto animate-in zoom-in-95 no-scrollbar">
              <div className="flex justify-between items-center mb-8">
                  <h3 className="text-xl font-black uppercase tracking-widest text-gray-900 dark:text-white">Editor de Producto</h3>
                  <button onClick={() => setIsEditingProduct(false)} className="p-2 bg-gray-50 dark:bg-zinc-800 rounded-full"><X size={20}/></button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                  <div className="md:col-span-2">
                      <label className={labelClass}>Nombre Comercial</label>
                      <input type="text" className={inputClass} value={editingProduct.name || ''} onChange={e => setEditingProduct({...editingProduct, name: e.target.value})} />
                  </div>
                  <div>
                      <label className={labelClass}>Marca</label>
                      <select className={inputClass} value={editingProduct.brand || ''} onChange={e => setEditingProduct({...editingProduct, brand: e.target.value})}>
                          <option value="">Seleccionar Marca</option>
                          {brands.map(b => <option key={b.id} value={b.name}>{b.name}</option>)}
                      </select>
                  </div>
                  <div>
                      <label className={labelClass}>Categoría</label>
                      <select className={inputClass} value={editingProduct.category || ''} onChange={e => setEditingProduct({...editingProduct, category: e.target.value})}>
                          <option value="">Seleccionar Categoría</option>
                          {categories.map(c => <option key={c.id} value={c.name}>{c.name}</option>)}
                      </select>
                  </div>
                  
                  {/* SEASONS INPUT (With DataList or Select/Custom logic) */}
                  <div>
                      <label className={labelClass}>Temporada / Colección</label>
                      <input 
                        type="text" 
                        list="seasons-list"
                        className={inputClass} 
                        value={editingProduct.season || 'Todo el año'} 
                        onChange={e => setEditingProduct({...editingProduct, season: e.target.value})}
                        placeholder="Ej: Navidad, Verano..." 
                      />
                      <datalist id="seasons-list">
                          {COMMON_SEASONS.map(s => <option key={s} value={s} />)}
                      </datalist>
                  </div>

                  <div>
                      <label className={labelClass}>SKU / Referencia</label>
                      <input type="text" className={inputClass} value={editingProduct.sku || ''} onChange={e => setEditingProduct({...editingProduct, sku: e.target.value})} />
                  </div>
                  <div>
                      <label className={labelClass}>Precio Venta ($)</label>
                      <input type="number" className={inputClass} value={editingProduct.price ?? ''} onChange={e => setEditingProduct({...editingProduct, price: e.target.value})} />
                  </div>
                  <div>
                      <label className={labelClass}>Precio Original (Tachado)</label>
                      <input type="number" className={inputClass} value={editingProduct.originalPrice ?? ''} onChange={e => setEditingProduct({...editingProduct, originalPrice: e.target.value})} />
                  </div>
                  <div>
                      <label className={labelClass}>Unidades por Display</label>
                      <input type="number" className={inputClass} value={editingProduct.unitsPerDisplay ?? 1} onChange={e => setEditingProduct({...editingProduct, unitsPerDisplay: e.target.value})} />
                  </div>
                  <div>
                      <label className={labelClass}>Stock Disponible</label>
                      <input type="number" className={inputClass} value={editingProduct.stock ?? ''} onChange={e => setEditingProduct({...editingProduct, stock: e.target.value})} />
                  </div>
                  <div className="md:col-span-2">
                      <label className={labelClass}>Imagen (URL o Archivo)</label>
                      <div className="flex gap-2">
                          <input type="text" className={inputClass} value={editingProduct.image || ''} onChange={e => setEditingProduct({...editingProduct, image: e.target.value})} placeholder="https://..." />
                          <label className="bg-gray-100 dark:bg-zinc-800 p-3 rounded-xl cursor-pointer hover:bg-gray-200"><input type="file" accept="image/*" className="hidden" onChange={(e) => handleImageUpload(e, 'product')} /><Upload size={20}/></label>
                      </div>
                  </div>

                  {/* PRICE SCALES (VOLUME DISCOUNTS) */}
                  <div className="md:col-span-2 bg-gray-50 dark:bg-zinc-800/50 p-6 rounded-[22px] border border-gray-100 dark:border-zinc-800">
                      <div className="flex items-center justify-between mb-4">
                         <label className={labelClass}>Descuentos por Volumen</label>
                         <button onClick={addPriceScale} className="text-[10px] font-black uppercase tracking-widest bg-brand text-white px-4 py-1.5 rounded-lg flex items-center gap-2" style={{ backgroundColor: theme.colors.brand }}><Plus size={12}/> Añadir Escala</button>
                      </div>
                      <div className="space-y-3">
                         {(editingProduct.priceScales || []).map((scale: any, idx: number) => (
                             <div key={idx} className="flex gap-3 items-center">
                                <div className="flex-1">
                                   <input type="number" placeholder="Min. Cant" className={inputClass} value={scale.minQuantity} onChange={e => updatePriceScale(idx, 'minQuantity', Number(e.target.value))} />
                                </div>
                                <div className="flex-1">
                                   <input type="number" placeholder="Precio ($)" className={inputClass} value={scale.price} onChange={e => updatePriceScale(idx, 'price', Number(e.target.value))} />
                                </div>
                                <button onClick={() => removePriceScale(idx)} className="p-3 text-red-500 bg-red-50 rounded-xl"><Trash2 size={18}/></button>
                             </div>
                         ))}
                      </div>
                  </div>

                  <div className="md:col-span-2 flex gap-4">
                      <label className="flex items-center gap-2 bg-gray-50 dark:bg-zinc-800 p-3 rounded-xl cursor-pointer">
                          <input type="checkbox" checked={editingProduct.isFeatured || false} onChange={e => setEditingProduct({...editingProduct, isFeatured: e.target.checked})} />
                          <span className="text-xs font-bold uppercase">Destacado</span>
                      </label>
                      <label className="flex items-center gap-2 bg-gray-50 dark:bg-zinc-800 p-3 rounded-xl cursor-pointer">
                          <input type="checkbox" checked={editingProduct.isPromotion || false} onChange={e => setEditingProduct({...editingProduct, isPromotion: e.target.checked})} />
                          <span className="text-xs font-bold uppercase">Promoción</span>
                      </label>
                  </div>
              </div>

              <div className="flex gap-4">
                  <button onClick={() => setIsEditingProduct(false)} className="px-8 py-5 bg-gray-100 dark:bg-zinc-800 rounded-2xl font-bold text-xs uppercase tracking-widest">Cancelar</button>
                  <button onClick={handleSaveProduct} disabled={isSaving} className="flex-1 bg-brand text-white py-5 rounded-2xl font-black text-xs uppercase tracking-widest flex items-center justify-center gap-2 shadow-xl" style={{ backgroundColor: theme.colors.brand }}>
                      {isSaving ? <Loader2 size={18} className="animate-spin" /> : <Save size={18}/>} Guardar Producto
                  </button>
              </div>
            </div>
          </div>
        )}

        {/* MODAL: BRAND EDITOR */}
        {isEditingBrand && (
           <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
              <div className="bg-white dark:bg-zinc-900 rounded-[28px] p-8 shadow-2xl w-full max-w-md">
                 <h3 className="text-lg font-black uppercase tracking-widest mb-6">Gestionar Marca</h3>
                 <div className="space-y-6 mb-8">
                    <div>
                       <label className={labelClass}>Nombre de la Marca</label>
                       <input type="text" className={inputClass} value={editingBrand.name || ''} onChange={e => setEditingBrand({...editingBrand, name: e.target.value})} />
                    </div>
                    <div>
                       <label className={labelClass}>Logo de Marca</label>
                       <div className="flex gap-2">
                          <input type="text" className={inputClass} value={editingBrand.image || ''} onChange={e => setEditingBrand({...editingBrand, image: e.target.value})} />
                          <label className="bg-gray-100 p-3 rounded-xl cursor-pointer"><input type="file" accept="image/*" className="hidden" onChange={(e) => handleImageUpload(e, 'brand')} /><Upload size={20}/></label>
                       </div>
                    </div>
                 </div>
                 <div className="flex gap-3">
                    <button onClick={() => setIsEditingBrand(false)} className="flex-1 py-4 bg-gray-100 rounded-2xl font-bold text-xs uppercase">Cancelar</button>
                    <button onClick={handleSaveBrand} className="flex-1 py-4 bg-brand text-white rounded-2xl font-black text-xs uppercase" style={{ backgroundColor: theme.colors.brand }}>Guardar</button>
                 </div>
              </div>
           </div>
        )}

        {/* MODAL: CATEGORY EDITOR */}
        {isEditingCategory && (
           <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
              <div className="bg-white dark:bg-zinc-900 rounded-[28px] p-8 shadow-2xl w-full max-w-md">
                 <h3 className="text-lg font-black uppercase tracking-widest mb-6">Gestionar Categoría</h3>
                 <div className="space-y-6 mb-8">
                    <div>
                       <label className={labelClass}>Nombre de Categoría</label>
                       <input type="text" className={inputClass} value={editingCategory.name || ''} onChange={e => setEditingCategory({...editingCategory, name: e.target.value})} />
                    </div>
                 </div>
                 <div className="flex gap-3">
                    <button onClick={() => setIsEditingCategory(false)} className="flex-1 py-4 bg-gray-100 rounded-2xl font-bold text-xs uppercase">Cancelar</button>
                    <button onClick={handleSaveCategory} className="flex-1 py-4 bg-brand text-white rounded-2xl font-black text-xs uppercase" style={{ backgroundColor: theme.colors.brand }}>Guardar</button>
                 </div>
              </div>
           </div>
        )}
      </div>
    </div>
  );
};

export default AdminPanel;
