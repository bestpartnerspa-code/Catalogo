
import React from 'react';
import { Product } from '../types';
import { useTheme } from '../contexts/ThemeContext';
import { useSettings } from '../contexts/SettingsContext';
import { Plus, Minus, Star, ShoppingBag, Tag, Sticker, Package } from 'lucide-react';
import CachedImage from './CachedImage';

interface ProductCardProps {
  product: Product;
  brandLogo?: string; // New prop for Brand Icon
  onAddToCart: (product: Product) => void;
  onUpdateQuantity: (product: Product, delta: number) => void;
  quantity: number;
  onClick: (product: Product) => void;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, brandLogo, onAddToCart, onUpdateQuantity, quantity, onClick }) => {
  const { theme } = useTheme();
  const { formatPrice } = useSettings();
  
  const isOutOfStock = product.stock <= 0;
  const isBig = product.isFeatured;

  // Resolve Card Background
  const cardBgStyle: React.CSSProperties = {
      borderRadius: '2rem',
      boxShadow: theme.darkMode ? 'none' : '0 10px 40px -10px rgba(0,0,0,0.05)',
  };

  if (!theme.darkMode) {
      if (theme.cardBackground.type === 'image') {
          cardBgStyle.backgroundImage = `url('${theme.cardBackground.value}')`;
          cardBgStyle.backgroundSize = 'cover';
          cardBgStyle.backgroundPosition = 'center';
      } else {
          cardBgStyle.backgroundColor = theme.cardBackground.value;
      }
  } else {
      cardBgStyle.backgroundColor = '#1e1e1e'; // Fallback dark mode
  }

  // Brand Icon Size Logic
  const getBrandIconClasses = () => {
    const size = theme.layout?.brandIconSize || 'medium';
    switch (size) {
      case 'small': return 'w-12 h-12';
      case 'large': return 'w-24 h-24';
      case 'medium': 
      default: return 'w-16 h-16';
    }
  };

  // Badge Scale Logic
  const getScaleClass = (size?: 'small' | 'medium' | 'large') => {
      if (size === 'small') return 'scale-75';
      if (size === 'large') return 'scale-125';
      return 'scale-100'; // medium/default
  };

  // Helper for Promo Badge
  const renderPromoBadge = () => {
      const style = theme.badges?.promoStyle || 'ribbon';
      const scaleClass = getScaleClass(theme.layout?.promoBadgeSize);
      
      // Calculate Discount if applicable
      let discountText = "OFERTA";
      if (product.originalPrice && product.originalPrice > product.price) {
          const percent = Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100);
          if (percent > 0) discountText = `${percent}% OFF`;
      }

      const wrapperClass = `absolute z-20 ${scaleClass} origin-top-left`;

      if (style === 'ribbon') {
          return (
             <div className={`${wrapperClass} -top-2 -left-2`}>
               <span className="text-4xl font-black text-gray-100 absolute select-none opacity-50 -rotate-12 scale-150 top-2 left-2" style={{ color: theme.colors.brand }}>SALE</span>
               <span className="relative text-lg font-black bg-black text-white px-3 py-1 -rotate-6 inline-block shadow-lg">PROMO</span>
             </div>
          );
      } else if (style === 'sticker') {
          return (
              <div className={`${wrapperClass} top-2 left-2`}>
                  <div className="w-12 h-12 bg-red-500 rounded-full flex items-center justify-center shadow-lg transform rotate-12">
                      <span className="text-[10px] font-black text-white text-center leading-none">{discountText}</span>
                  </div>
              </div>
          );
      } else if (style === 'flag') {
          return (
              <div className={`${wrapperClass} top-0 left-4`}>
                  <div className="bg-red-600 text-white w-8 h-10 flex items-end justify-center pb-2 shadow-md" style={{ clipPath: 'polygon(0 0, 100% 0, 100% 100%, 50% 80%, 0 100%)' }}>
                      <Star size={12} fill="white" />
                  </div>
              </div>
          );
      } else if (style === 'big-ribbon') {
          return (
             <div className={`${wrapperClass} top-0 left-0`}>
                 <div className="overflow-hidden w-28 h-28 pointer-events-none rounded-tl-[2rem] relative">
                     <div className="absolute top-0 left-0 transform -translate-x-[30%] -translate-y-[30%] rotate-[-45deg] bg-red-600 text-white w-[160%] py-1.5 text-center shadow-xl origin-bottom-right flex flex-col items-center justify-center z-30">
                          <span className="text-[9px] font-black tracking-widest block border-b border-white/30 pb-0.5 mb-0.5 w-full opacity-90">ESPECIAL</span>
                          <span className="text-sm font-black tracking-tight leading-none drop-shadow-md">OFERTA</span>
                     </div>
                     <div className="absolute top-0 left-0 transform -translate-x-[28%] -translate-y-[28%] rotate-[-45deg] bg-black/30 w-[160%] h-12 blur-md"></div>
                 </div>
             </div>
          );
      } else if (style === 'discount-tag') {
          return (
              <div className={`${wrapperClass} top-4 left-0`}>
                  <div className="relative h-10 flex items-center pl-3 pr-4 text-white shadow-md transform -rotate-12 origin-top-left" style={{ backgroundColor: '#dc2626' }}>
                      <div className="absolute right-[-10px] top-0 bottom-0 w-4 bg-[#dc2626]" style={{ clipPath: 'polygon(0 0, 100% 50%, 0 100%)' }}></div>
                      <div className="absolute left-[-2px] top-[14px] w-1.5 h-1.5 bg-white rounded-full shadow-inner"></div>
                      <span className="text-sm font-black tracking-tighter transform rotate-0 ml-1 drop-shadow-sm leading-none flex flex-col items-center">
                          {discountText}
                      </span>
                      {/* String simulation */}
                      <div className="absolute top-1/2 left-0 w-3 h-12 border-l border-b border-white/30 rounded-bl-xl transform -translate-x-full -translate-y-full opacity-50"></div>
                  </div>
              </div>
          );
      }
      return null;
  };

  // Helper for Price Badge
  const renderPriceBadge = () => {
      const style = theme.badges?.priceStyle || 'circle';
      const scaleClass = getScaleClass(theme.layout?.priceBadgeSize);
      const displayPrice = formatPrice(product.price).replace('$', '');
      
      // Calculation for unit price display inside badge if needed, though usually better outside
      // We will render only the main Display Price in the badge for impact.

      // Most price badges are bottom-right, so set origin there
      const wrapperClass = `absolute z-20 ${scaleClass} origin-bottom-right`;

      if (style === 'circle') {
          return (
             <div className={`${wrapperClass} ${isBig ? 'bottom-0 right-0' : '-bottom-2 -right-2'}`}>
                 <div className={`
                    flex flex-col items-center justify-center rounded-full border-2 border-dashed bg-white/90 dark:bg-black/80 backdrop-blur-sm shadow-xl
                    ${isBig ? 'w-28 h-28 border-gray-900 dark:border-white' : 'w-20 h-20 border-gray-300 dark:border-zinc-700'}
                 `}>
                    <span className={`font-black leading-none ${isBig ? 'text-[10px]' : 'text-[8px]'} uppercase tracking-widest text-gray-500`}>Only</span>
                    <span className={`font-black leading-none ${isBig ? 'text-3xl' : 'text-xl'}`} style={{ color: theme.colors.brand }}>{displayPrice}</span>
                    <span className={`font-bold leading-none ${isBig ? 'text-[10px]' : 'text-[8px]'} text-gray-400`}>CLP</span>
                 </div>
             </div>
          );
      } else if (style === 'tag') {
          return (
              <div className={`${wrapperClass} bottom-4 right-0`}>
                  <div className={`bg-brand text-white pl-4 pr-3 py-1.5 rounded-l-xl shadow-lg flex flex-col items-end`}>
                      <span className="text-[10px] opacity-80 font-bold uppercase tracking-widest">Precio</span>
                      <span className="text-xl font-black leading-none">{displayPrice}</span>
                  </div>
              </div>
          );
      } else if (style === 'minimal') {
          return (
              <div className={`${wrapperClass} bottom-2 right-4`}>
                  <div className="flex flex-col items-end">
                      <span className="text-2xl font-black" style={{ color: theme.colors.brand }}>{displayPrice}</span>
                      <span className="text-[10px] font-bold text-gray-400">CLP</span>
                  </div>
              </div>
          );
      } else if (style === 'starburst') {
          // 30-point Starburst Path
          return (
             <div className={`${wrapperClass} -bottom-4 -right-4`}>
                <div className={`relative w-24 h-24 flex items-center justify-center animate-in zoom-in duration-300 ${isBig ? 'scale-125' : 'scale-100'}`}>
                    {/* Background Star */}
                    <svg viewBox="0 0 100 100" className="absolute inset-0 w-full h-full drop-shadow-lg" style={{ color: theme.colors.brand }}>
                        {/* 30-point Star Polygon (Outer Radius 50, Inner 42) */}
                        <polygon points="50,0 55.2,10.5 66.2,6.7 67.6,18.3 78.4,18.3 76.1,29.7 85.4,33.7 79.9,43.7 86.6,50 79.9,56.3 85.4,66.3 76.1,70.3 78.4,81.7 67.6,81.7 66.2,93.3 55.2,89.5 50,100 44.8,89.5 33.8,93.3 32.4,81.7 21.6,81.7 23.9,70.3 14.6,66.3 20.1,56.3 13.4,50 20.1,43.7 14.6,33.7 23.9,29.7 21.6,18.3 32.4,18.3 33.8,6.7 44.8,10.5" fill="currentColor"/>
                        {/* Inner stroke effect */}
                        <circle cx="50" cy="50" r="38" fill="white" fillOpacity="0.1" />
                    </svg>
                    <div className="relative z-10 flex flex-col items-center justify-center text-white pb-1 pr-0.5 transform -rotate-[15deg]">
                        <span className="text-[7px] font-black uppercase tracking-widest opacity-90">Oferta</span>
                        <span className="text-xl font-black leading-none tracking-tighter drop-shadow-md">{displayPrice}</span>
                        <span className="text-[7px] font-bold">CLP</span>
                    </div>
                </div>
             </div>
          );
      } else if (style === 'arrow') {
          return (
             <div className={`${wrapperClass} bottom-6 right-0 ${isBig ? 'scale-110' : ''}`}>
                 <div className="h-10 flex items-center shadow-lg">
                     <div className="h-full bg-red-600 flex items-center pl-3 pr-1 text-white">
                         <span className="text-xl font-black tracking-tighter">{displayPrice}</span>
                     </div>
                     <div className="h-full w-5 bg-red-600" style={{ clipPath: 'polygon(0 0, 0 100%, 100% 50%)' }}></div>
                 </div>
             </div>
          );
      }
      return null;
  };

  // Logic to calculate unit price
  const displayUnitPrice = product.unitPrice || (product.unitsPerDisplay && product.unitsPerDisplay > 1 ? Math.round(product.price / product.unitsPerDisplay) : null);

  return (
    <div 
      className={`
        h-full w-full relative flex flex-col items-center text-center p-4 
        transition-all duration-500
        hover:shadow-2xl hover:-translate-y-1
      `}
      style={cardBgStyle}
      onClick={() => onClick(product)}
    >
      {/* Background Decor (Subtle Blob for "Big" items) */}
      {isBig && (
         <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[90%] h-[90%] rounded-full opacity-5 pointer-events-none" style={{ backgroundColor: theme.colors.brand }}></div>
      )}

      {/* Brand Logo in Top Right Corner */}
      {brandLogo && (
        <div className={`absolute top-4 right-4 z-20 flex items-center justify-center pointer-events-none ${getBrandIconClasses()}`}>
           <img src={brandLogo} alt={product.brand} className="w-full h-full object-contain drop-shadow-sm" />
        </div>
      )}

      {/* Product Image - Aspect Square ensures responsiveness */}
      <div className={`relative z-10 mb-4 flex-shrink-0 w-full aspect-square p-2`}>
         <CachedImage 
            src={product.image} 
            className={`w-full h-full object-contain drop-shadow-xl transform transition-transform duration-700 group-hover:scale-110 ${isOutOfStock ? 'grayscale opacity-75' : ''}`} 
         />
         
         {product.isPromotion && !isOutOfStock && renderPromoBadge()}

         {/* AGOTADO STRIP */}
         {isOutOfStock && (
           <div className="absolute inset-0 flex items-center justify-center z-30 pointer-events-none">
             <div className="w-[120%] h-12 bg-red-600 shadow-xl flex items-center justify-center -rotate-12 transform origin-center border-y-4 border-white/20">
               <span className="text-white font-black text-xl tracking-[0.3em] drop-shadow-md">AGOTADO</span>
             </div>
           </div>
         )}

         {theme.showPrices && renderPriceBadge()}
      </div>

      {/* Content */}
      <div className="flex flex-col items-center w-full z-10 mt-auto">
         <span className="text-[10px] font-black tracking-[0.2em] uppercase text-gray-400 mb-2">{product.brand}</span>
         <h3 className={`font-black uppercase tracking-tighter leading-none mb-1 ${theme.darkMode ? 'text-white' : 'text-gray-900'} ${isBig ? 'text-2xl' : 'text-lg line-clamp-2'}`}>
            {product.name}
         </h3>
         
         {/* Unit Price Display */}
         {theme.showPrices && displayUnitPrice && !isOutOfStock && (
             <div className="mb-3 flex items-center gap-1 opacity-70">
                 <Package size={12} className="text-gray-500" />
                 <span className="text-[10px] font-bold text-gray-500 dark:text-gray-400">
                    {formatPrice(displayUnitPrice)} c/u
                 </span>
             </div>
         )}
         {!displayUnitPrice && <div className="mb-4"></div>}

         {/* Action Area */}
         <div onClick={e => e.stopPropagation()} className="w-full mt-auto">
            {quantity > 0 ? (
                <div className="flex items-center justify-center bg-black dark:bg-white text-white dark:text-black rounded-full w-full max-w-[140px] mx-auto py-1 px-1 shadow-lg">
                    <button onClick={() => onUpdateQuantity(product, -1)} className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-white/20 dark:hover:bg-black/10"><Minus size={16}/></button>
                    <span className="flex-1 text-center font-black text-sm">{quantity}</span>
                    <button onClick={() => onUpdateQuantity(product, 1)} className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-white/20 dark:hover:bg-black/10" disabled={product.stock <= quantity}><Plus size={16}/></button>
                </div>
            ) : (
                <button 
                  onClick={() => onAddToCart(product)} 
                  disabled={isOutOfStock}
                  className={`
                    w-full max-w-[140px] py-2.5 rounded-full font-black text-xs uppercase tracking-widest flex items-center justify-center gap-2 transition-all
                    ${isOutOfStock 
                        ? 'bg-gray-100 text-gray-400 cursor-not-allowed opacity-50' 
                        : 'bg-gray-100 text-gray-900 hover:bg-brand hover:text-white dark:bg-zinc-800 dark:text-white dark:hover:bg-brand shadow-sm hover:shadow-xl hover:scale-105'}
                  `}
                >
                  {isOutOfStock ? (
                    'Sold Out'
                  ) : (
                    <>
                      <ShoppingBag size={14} className="mb-0.5" />
                      Add to Cart
                    </>
                  )}
                </button>
            )}
         </div>
      </div>
    </div>
  );
};

export default ProductCard;
