import React, { useState, useEffect, useRef } from 'react';
import { dbService } from '../services/db';

interface CachedImageProps extends React.ImgHTMLAttributes<HTMLImageElement> {
  src: string;
}

const CachedImage: React.FC<CachedImageProps> = ({ src, alt, className, style, ...props }) => {
  const [imageSrc, setImageSrc] = useState<string | null>(null);
  const [isVisible, setIsVisible] = useState(false);
  const imgRef = useRef<HTMLImageElement>(null);
  const objectUrlRef = useRef<string | null>(null);

  // Intersection Observer for Lazy Loading
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setIsVisible(true);
            observer.disconnect();
          }
        });
      },
      { rootMargin: '100px' } // Start loading 100px before appearing
    );

    if (imgRef.current) {
      observer.observe(imgRef.current);
    }

    return () => observer.disconnect();
  }, []);

  // Fetch & Cache Logic
  useEffect(() => {
    if (!isVisible || !src) return;

    let isActive = true;

    const fetchImage = async () => {
      try {
        // 1. Try DB first
        const cachedBlob = await dbService.getCachedImage(src);
        
        if (cachedBlob) {
          const url = URL.createObjectURL(cachedBlob);
          if (isActive) {
            objectUrlRef.current = url;
            setImageSrc(url);
          }
          return;
        }

        // 2. Fetch from Network
        const response = await fetch(src, { mode: 'cors', credentials: 'omit' });
        if (!response.ok) throw new Error('Failed to load image');
        
        const blob = await response.blob();
        
        // 3. Save to DB (Fire and forget, but log error)
        dbService.saveCachedImage(src, blob).catch(err => 
          console.warn('Failed to cache image:', err)
        );

        const url = URL.createObjectURL(blob);
        if (isActive) {
          objectUrlRef.current = url;
          setImageSrc(url);
        }

      } catch (err) {
        console.warn('Image caching failed, falling back to source', src, err);
        if (isActive) setImageSrc(src); // Fallback to normal browser loading
      }
    };

    fetchImage();

    return () => {
      isActive = false;
      if (objectUrlRef.current) {
        URL.revokeObjectURL(objectUrlRef.current);
        objectUrlRef.current = null;
      }
    };
  }, [src, isVisible]);

  return (
    <img
      ref={imgRef}
      // Use a transparent 1x1 pixel as placeholder to maintain layout if container has size, 
      // or to hide if not loaded yet.
      src={imageSrc || 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7'}
      alt={alt}
      className={`${className} transition-opacity duration-500 ${imageSrc ? 'opacity-100' : 'opacity-0'}`}
      style={style}
      {...props}
    />
  );
};

export default CachedImage;