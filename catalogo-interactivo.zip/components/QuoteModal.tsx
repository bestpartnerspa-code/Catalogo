
import React, { useState } from 'react';
import { Product } from '../types';
import { useTheme } from '../contexts/ThemeContext';
import { useSettings } from '../contexts/SettingsContext';
import { dbService } from '../services/db';
import { X, Loader2, Plus, Minus, Trash2, ShoppingBag, Send, Trash } from 'lucide-react';
import CachedImage from './CachedImage';
// @ts-ignore
import { jsPDF } from 'jspdf';

interface QuoteModalProps {
  isOpen: boolean;
  onClose: () => void;
  cart: Product[];
  cartGroups: { product: Product; count: number }[];
  total: number;
  onUpdateQuantity: (product: Product, delta: number) => void;
  onClearCart: () => void;
}

const QuoteModal: React.FC<QuoteModalProps> = ({ isOpen, onClose, cartGroups, total, onUpdateQuantity, onClearCart }) => {
  const { theme } = useTheme();
  const { t, formatPrice } = useSettings();
  const [isGenerating, setIsGenerating] = useState(false);

  if (!isOpen) return null;

  const isEmpty = cartGroups.length === 0;

  const handleClearCart = () => {
    // Just clear, no confirmation required per user request
    onClearCart();
  };

  const getImageData = async (url: string): Promise<string | null> => {
    try {
      const cachedBlob = await dbService.getCachedImage(url);
      if (cachedBlob) {
        return new Promise((resolve) => {
          const reader = new FileReader();
          reader.onloadend = () => resolve(reader.result as string);
          reader.readAsDataURL(cachedBlob);
        });
      }
      return null;
    } catch (e) {
      return null;
    }
  };

  const generateAndSharePdf = async () => {
    if (isEmpty) return;
    setIsGenerating(true);

    try {
      const doc = new jsPDF();
      const pageWidth = doc.internal.pageSize.getWidth();
      const margin = 15;
      let y = 25;

      const today = new Date();
      const expDate = new Date();
      expDate.setDate(today.getDate() + 15);

      doc.setFillColor(theme.colors.brand);
      doc.rect(0, 0, 8, 297, 'F');

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(28);
      doc.setTextColor(theme.colors.brand);
      doc.text(theme.appName || 'BEST PARTNER', margin + 5, y);
      
      doc.setFontSize(11);
      doc.setTextColor(140);
      doc.setFont('helvetica', 'normal');
      doc.text('COTIZACIÓN PROFESIONAL', margin + 5, y + 8);
      
      doc.setFontSize(9);
      doc.setTextColor(80);
      doc.text(`Fecha: ${today.toLocaleDateString()}`, pageWidth - margin, y, { align: 'right' });
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(theme.colors.brand);
      doc.text(`VIGENCIA: 15 DÍAS (Hasta ${expDate.toLocaleDateString()})`, pageWidth - margin, y + 8, { align: 'right' });

      y += 25;
      doc.setDrawColor(theme.colors.brand);
      doc.setLineWidth(1.5);
      doc.line(margin + 5, y, pageWidth - margin, y);

      y += 12;
      doc.setFillColor(250, 250, 250);
      doc.rect(margin + 5, y, pageWidth - (margin * 2) - 5, 12, 'F');
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(10);
      doc.setTextColor(60);
      doc.text('PROD', margin + 10, y + 7.5);
      doc.text('DESCRIPCIÓN', margin + 25, y + 7.5);
      doc.text('CANT', pageWidth - 70, y + 7.5, { align: 'right' });
      doc.text('TOTAL', pageWidth - margin - 5, y + 7.5, { align: 'right' });

      y += 20;

      for (const { product, count } of cartGroups) {
        if (y > 260) { 
          doc.addPage(); 
          y = 20;
          doc.setFillColor(theme.colors.brand);
          doc.rect(0, 0, 8, 297, 'F');
        }

        // Miniatura Imagen
        const imgData = await getImageData(product.image);
        if (imgData) {
          try {
            doc.addImage(imgData, 'JPEG', margin + 8, y - 8, 12, 12);
          } catch(e) {}
        }

        doc.setFont('helvetica', 'bold');
        doc.setFontSize(10);
        doc.setTextColor(20);
        const truncatedName = product.name.length > 45 ? product.name.substring(0, 42) + '...' : product.name;
        doc.text(truncatedName.toUpperCase(), margin + 25, y - 4);
        
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(8);
        doc.setTextColor(120);
        doc.text(`SKU: ${product.sku} | Unitario: ${formatPrice(product.price)}`, margin + 25, y + 1);

        doc.setFont('helvetica', 'bold');
        doc.setFontSize(10);
        doc.setTextColor(40);
        doc.text(count.toString(), pageWidth - 70, y - 1, { align: 'right' });
        doc.text(formatPrice(product.price * count), pageWidth - margin - 5, y - 1, { align: 'right' });

        y += 16;
        doc.setDrawColor(245);
        doc.setLineWidth(0.5);
        doc.line(margin + 10, y - 8, pageWidth - margin - 5, y - 8);
      }

      if (y > 240) { doc.addPage(); y = 30; doc.setFillColor(theme.colors.brand); doc.rect(0, 0, 8, 297, 'F'); }
      
      y += 10;
      doc.setFillColor(theme.colors.brand);
      doc.rect(pageWidth - 100, y, 85, 20, 'F');
      
      doc.setTextColor(255);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(12);
      doc.text('TOTAL ESTIMADO:', pageWidth - 95, y + 12);
      doc.setFontSize(18);
      doc.text(formatPrice(total), pageWidth - margin - 5, y + 13, { align: 'right' });

      y += 35;
      doc.setFontSize(8);
      doc.setTextColor(150);
      doc.setFont('helvetica', 'normal');
      doc.text('Documento generado automáticamente. Los precios y stock están sujetos a confirmación final.', pageWidth / 2, 285, { align: 'center' });

      const pdfBlob = doc.output('blob');
      const fileName = `Cotizacion_${theme.appName?.replace(/\s+/g, '_')}.pdf`;
      const file = new File([pdfBlob], fileName, { type: 'application/pdf' });

      if (navigator.canShare && navigator.canShare({ files: [file] })) {
        await navigator.share({
          files: [file],
          title: 'Cotización',
          text: `Adjunto cotización de ${theme.appName}.`,
        });
      } else {
        doc.save(fileName);
        alert("PDF descargado correctamente.");
      }
    } catch (error) {
      console.error("PDF generation failed:", error);
      alert("Error al generar el PDF.");
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-2 sm:p-4">
      <div className="absolute inset-0 bg-black/80 backdrop-blur-md" onClick={onClose} />

      <div className="relative bg-white w-full max-w-4xl max-h-[95vh] overflow-hidden shadow-2xl rounded-2xl flex flex-col animate-in fade-in slide-in-from-bottom-4 duration-300">
        <div className="bg-zinc-50 border-b p-4 sm:px-6 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="bg-brand/10 p-2 rounded-xl text-brand">
               <ShoppingBag size={20}/>
            </div>
            <div>
              <h2 className="font-black text-gray-900 text-xs uppercase tracking-widest leading-none">Mi Pedido</h2>
              <span className="text-[10px] font-bold text-gray-400 uppercase tracking-tighter">{cartGroups.length} ítems seleccionados</span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {!isEmpty && (
              <button 
                onClick={handleClearCart}
                className="p-2 text-red-500 hover:bg-red-50 rounded-full transition-colors flex items-center gap-1 font-black text-[10px] uppercase tracking-widest"
              >
                <Trash size={18} />
                <span className="hidden sm:inline">Vaciar</span>
              </button>
            )}
            <button onClick={onClose} className="p-2 hover:bg-gray-200 rounded-full transition-colors">
              <X size={24} className="text-gray-400 hover:text-gray-900"/>
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto no-scrollbar p-4 sm:p-6 bg-gray-50/30">
          {isEmpty ? (
            <div className="flex flex-col items-center justify-center py-20 text-center">
              <ShoppingBag size={64} className="text-gray-200 mb-4" />
              <h3 className="text-lg font-black text-gray-900 uppercase">El carrito está vacío</h3>
              <button onClick={onClose} className="mt-6 bg-brand text-white px-8 py-3 rounded-xl font-black text-xs uppercase tracking-widest">Ir al Catálogo</button>
            </div>
          ) : (
            <div className="space-y-3">
              {cartGroups.map(({ product, count }) => (
                <div key={product.id} className="bg-white p-4 rounded-2xl border border-gray-100 shadow-sm flex items-center gap-4 group">
                   <div className="h-16 w-16 rounded-xl overflow-hidden bg-gray-50 flex-shrink-0">
                      <CachedImage src={product.image} className="w-full h-full object-cover" />
                   </div>
                   <div className="flex-1 min-w-0">
                      <h4 className="font-black text-sm uppercase truncate text-gray-900">{product.name}</h4>
                      <span className="text-[10px] font-mono font-bold text-gray-400">{product.sku}</span>
                      <div className="mt-1">
                        {theme.showPrices && <span className="text-xs font-black text-brand">{formatPrice(product.price)}</span>}
                      </div>
                   </div>
                   <div className="flex flex-col items-end gap-2">
                      <div className="flex items-center bg-gray-100 rounded-lg p-1">
                         <button onClick={() => onUpdateQuantity(product, -1)} className="p-1 hover:bg-white rounded-md"><Minus size={14}/></button>
                         <span className="w-8 text-center font-black text-xs">{count}</span>
                         <button onClick={() => onUpdateQuantity(product, 1)} className="p-1 hover:bg-white rounded-md" disabled={product.stock <= count}><Plus size={14}/></button>
                      </div>
                      <button onClick={() => onUpdateQuantity(product, -count)} className="text-[10px] font-black text-red-500 uppercase flex items-center gap-1 opacity-60 hover:opacity-100">
                         <Trash2 size={12}/> Eliminar
                      </button>
                   </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {!isEmpty && (
          <div className="p-4 bg-white border-t flex items-center justify-between">
             {theme.showPrices ? (
                 <div>
                    <span className="text-[10px] font-black text-gray-400 uppercase block tracking-widest mb-1">Total Estimado</span>
                    <span className="text-2xl font-black text-brand leading-none">{formatPrice(total)}</span>
                 </div>
             ) : (
                 <div>
                    <span className="text-[10px] font-black text-gray-400 uppercase block tracking-widest mb-1">Total</span>
                    <span className="text-xl font-black text-gray-400 leading-none">A Cotizar</span>
                 </div>
             )}
             <button 
                onClick={generateAndSharePdf} 
                disabled={isGenerating}
                className="bg-brand text-white px-8 py-4 rounded-xl font-black text-xs uppercase tracking-widest shadow-xl flex items-center gap-2 disabled:opacity-50 active:scale-95 transition-all"
             >
                {isGenerating ? <Loader2 size={18} className="animate-spin" /> : <Send size={18} />}
                Enviar Cotización
             </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default QuoteModal;