
import React, { useState, useEffect, useRef } from 'react';
import { Product, Brand } from '../types';
import { useTheme } from '../contexts/ThemeContext';
import { useSettings } from '../contexts/SettingsContext';
import { X, ShoppingCart, Tag, Box, ArrowLeft, Heart, Share2, Plus, Minus, Package, Grid, Maximize2, ChevronLeft, ChevronRight } from 'lucide-react';
import CachedImage from './CachedImage';

interface ProductModalProps {
  product: Product;
  allProducts?: Product[];
  brands?: Brand[];
  isOpen: boolean;
  onClose: () => void;
  onSelectProduct?: (product: Product) => void;
  onAddToCart: (product: Product, quantity: number) => void;
}

const ProductModal: React.FC<ProductModalProps> = ({ product, allProducts = [], brands = [], isOpen, onClose, onSelectProduct, onAddToCart }) => {
  const { theme } = useTheme();
  const { t, formatPrice } = useSettings();
  const [quantity, setQuantity] = useState(1);
  const [isFavorite, setIsFavorite] = useState(false);
  
  // Image Gallery State
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [isZoomed, setIsZoomed] = useState(false);

  // Combine main image and additional images
  const allImages = React.useMemo(() => {
      const imgs = [];
      if (product.image) imgs.push(product.image);
      if (product.images && product.images.length > 0) {
          product.images.forEach(img => {
              if (img !== product.image) imgs.push(img);
          });
      }
      return imgs.length > 0 ? imgs : ['']; // Fallback
  }, [product]);

  // Find brand logo
  const brandLogo = brands.find(b => b.name === product.brand)?.image;

  useEffect(() => {
    setQuantity(1);
    setIsFavorite(false);
    setCurrentImageIndex(0);
    setIsZoomed(false);
  }, [product.id]);

  // Calculate related products
  const relatedProducts = React.useMemo(() => {
      return allProducts.filter(p => 
          p.id !== product.id && 
          (p.category === product.category || p.brand === product.brand)
      ).slice(0, 6);
  }, [product, allProducts]);

  if (!isOpen) return null;

  const isOutOfStock = product.stock <= 0;

  // Unit Price Logic
  const displayUnitPrice = product.unitPrice || (product.unitsPerDisplay && product.unitsPerDisplay > 1 ? Math.round(product.price / product.unitsPerDisplay) : null);

  const handleIncrement = () => {
    if (quantity < product.stock) setQuantity(q => q + 1);
  };

  const handleDecrement = () => {
    if (quantity > 1) setQuantity(q => q - 1);
  };

  const currentPrice = product.price * quantity;

  // --- SWIPE LOGIC ---
  const touchStart = useRef<number | null>(null);
  const touchEnd = useRef<number | null>(null);

  const onTouchStart = (e: React.TouchEvent) => {
    touchEnd.current = null;
    touchStart.current = e.targetTouches[0].clientX;
  };

  const onTouchMove = (e: React.TouchEvent) => {
    touchEnd.current = e.targetTouches[0].clientX;
  };

  const onTouchEnd = () => {
    if (!touchStart.current || !touchEnd.current) return;
    const distance = touchStart.current - touchEnd.current;
    const isLeftSwipe = distance > 50;
    const isRightSwipe = distance < -50;

    if (isLeftSwipe) {
        nextImage();
    } else if (isRightSwipe) {
        prevImage();
    }
  };

  const nextImage = (e?: React.MouseEvent) => {
      e?.stopPropagation();
      setCurrentImageIndex((prev) => (prev + 1) % allImages.length);
  };

  const prevImage = (e?: React.MouseEvent) => {
      e?.stopPropagation();
      setCurrentImageIndex((prev) => (prev - 1 + allImages.length) % allImages.length);
  };

  return (
    <div className="fixed inset-0 z-[100] flex justify-center bg-black/60 backdrop-blur-sm">
        
      {/* Container - Max Width for Desktop to mimic Mobile View */}
      <div className="relative w-full max-w-lg h-full bg-white dark:bg-zinc-900 flex flex-col shadow-2xl animate-in slide-in-from-bottom-10 duration-300">
        
        {/* --- HEADER NAV (Absolute) --- */}
        <div className="absolute top-0 left-0 right-0 z-20 p-4 flex justify-between items-start pointer-events-none">
            <button 
                onClick={onClose} 
                className="pointer-events-auto w-10 h-10 bg-white dark:bg-zinc-800 rounded-full shadow-lg flex items-center justify-center text-gray-700 dark:text-white active:scale-90 transition-transform"
            >
                <ArrowLeft size={20} strokeWidth={2.5}/>
            </button>
            <div className="flex gap-3 pointer-events-auto">
                <button 
                    className="w-10 h-10 bg-white dark:bg-zinc-800 rounded-full shadow-lg flex items-center justify-center text-gray-700 dark:text-white active:scale-90 transition-transform"
                    onClick={() => {
                        if (navigator.share) {
                            navigator.share({ title: product.name, text: `Mira este producto: ${product.name}`, url: window.location.href });
                        }
                    }}
                >
                    <Share2 size={18} strokeWidth={2.5}/>
                </button>
                <button 
                    onClick={() => setIsFavorite(!isFavorite)}
                    className="w-10 h-10 bg-white dark:bg-zinc-800 rounded-full shadow-lg flex items-center justify-center active:scale-90 transition-transform"
                >
                    <Heart size={18} strokeWidth={2.5} className={isFavorite ? "fill-red-500 text-red-500" : "text-gray-700 dark:text-white"}/>
                </button>
            </div>
        </div>

        {/* --- SCROLLABLE CONTENT --- */}
        <div className="flex-1 overflow-y-auto no-scrollbar pb-32 bg-white dark:bg-zinc-900">
            
            {/* 1. PRODUCT IMAGE GALLERY AREA */}
            <div className="relative w-full aspect-square bg-gray-50 dark:bg-zinc-800 rounded-b-[2.5rem] overflow-hidden group">
                
                {/* Swipeable Container */}
                <div 
                    className="w-full h-full flex items-center justify-center pt-16 pb-6 px-8 cursor-grab active:cursor-grabbing"
                    onTouchStart={onTouchStart}
                    onTouchMove={onTouchMove}
                    onTouchEnd={onTouchEnd}
                >
                    <CachedImage 
                        key={currentImageIndex} // Force re-render on change for animation if needed, or rely on src change
                        src={allImages[currentImageIndex]} 
                        className={`w-full h-full object-contain drop-shadow-xl mix-blend-multiply dark:mix-blend-normal transition-all duration-300 animate-in fade-in zoom-in-95 ${isOutOfStock ? 'grayscale opacity-70' : ''}`} 
                    />
                </div>

                {/* Navigation Arrows (Desktop/Tablet) */}
                {allImages.length > 1 && (
                    <>
                        <button onClick={prevImage} className="absolute left-2 top-1/2 -translate-y-1/2 p-2 bg-white/50 hover:bg-white rounded-full shadow-sm opacity-0 group-hover:opacity-100 transition-opacity md:flex hidden"><ChevronLeft size={20}/></button>
                        <button onClick={nextImage} className="absolute right-2 top-1/2 -translate-y-1/2 p-2 bg-white/50 hover:bg-white rounded-full shadow-sm opacity-0 group-hover:opacity-100 transition-opacity md:flex hidden"><ChevronRight size={20}/></button>
                    </>
                )}

                {/* Zoom Button */}
                <button 
                    onClick={() => setIsZoomed(true)}
                    className="absolute bottom-6 right-6 p-2 bg-white/80 dark:bg-black/50 rounded-full backdrop-blur-sm text-gray-700 dark:text-white shadow-sm z-10"
                >
                    <Maximize2 size={20} />
                </button>
                
                {/* Format Pill (Bottom Left of Image) */}
                {product.unitsPerDisplay && product.unitsPerDisplay > 1 && (
                    <div className="absolute bottom-6 left-6 bg-gray-900 text-white dark:bg-white dark:text-black px-4 py-2 rounded-xl flex items-center gap-2 shadow-xl z-10">
                        <Grid size={16}/>
                        <span className="text-xs font-black tracking-widest uppercase">x{product.unitsPerDisplay} Unid.</span>
                    </div>
                )}

                {/* Pagination Dots */}
                {allImages.length > 1 && (
                    <div className="absolute bottom-2 left-0 right-0 flex justify-center gap-2">
                        {allImages.map((_, idx) => (
                            <div 
                                key={idx} 
                                className={`w-2 h-2 rounded-full transition-all ${idx === currentImageIndex ? 'bg-brand w-4' : 'bg-gray-300 dark:bg-zinc-600'}`}
                                style={idx === currentImageIndex ? { backgroundColor: theme.colors.brand } : {}}
                            />
                        ))}
                    </div>
                )}
            </div>

            {/* 2. MAIN INFO */}
            <div className="px-6 pt-8">
                {/* Drag Handle (Visual only) */}
                <div className="w-10 h-1 bg-gray-200 dark:bg-zinc-700 rounded-full mx-auto mb-6"></div>

                <div className="flex items-start justify-between mb-2">
                    <div className="space-y-1">
                        <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">
                            {product.category} • {product.sku}
                        </p>
                        <h1 className="text-3xl font-black uppercase text-gray-900 dark:text-white leading-tight max-w-[280px]">
                            {product.name}
                        </h1>
                    </div>
                    {/* Brand Logo */}
                    <div className="mt-1">
                        {brandLogo ? (
                             <img src={brandLogo} alt={product.brand} className="h-8 w-auto object-contain bg-white px-2 rounded-md border border-gray-100" />
                        ) : (
                             <span className="bg-brand/10 text-brand px-2 py-1 rounded text-[10px] font-black uppercase">{product.brand}</span>
                        )}
                    </div>
                </div>

                {/* Price Row */}
                <div className="flex flex-col mb-8">
                    <div className="flex items-baseline gap-2">
                         <span className="text-4xl font-black tracking-tighter" style={{ color: theme.colors.brand }}>
                            {formatPrice(product.price)}
                         </span>
                         {product.originalPrice && (
                             <span className="text-sm font-bold text-gray-300 line-through decoration-2">
                                 {formatPrice(product.originalPrice)}
                             </span>
                         )}
                    </div>
                    {displayUnitPrice && (
                        <div className="text-xs font-bold text-gray-400 mt-1">
                            PRECIO DISPLAY <span className="text-gray-300 px-1">|</span> {formatPrice(displayUnitPrice)} c/u
                        </div>
                    )}
                </div>

                {/* 3. VOLUME DISCOUNTS (Green Card) */}
                {product.priceScales && product.priceScales.length > 0 && (
                    <div className="mb-8 bg-green-50 dark:bg-green-900/10 rounded-3xl p-5 border border-green-100 dark:border-green-900/30">
                        <div className="flex items-center gap-2 mb-4 text-green-800 dark:text-green-400">
                             <Tag size={18} className="fill-green-600/20"/> 
                             <span className="text-xs font-black uppercase tracking-widest">Descuentos por Volumen</span>
                        </div>
                        
                        <div className="space-y-3">
                             {product.priceScales.map((scale, idx) => (
                                 <div key={idx} className="flex items-center justify-between">
                                     <div className="flex items-center gap-3">
                                         <div className="w-6 h-6 rounded-full bg-green-200 dark:bg-green-800 flex items-center justify-center text-[10px] font-black text-green-800 dark:text-green-100">
                                            {idx + 1}
                                         </div>
                                         <span className="text-sm font-bold text-gray-700 dark:text-gray-300">+{scale.minQuantity} un.</span>
                                     </div>
                                     <span className="text-sm font-black text-green-700 dark:text-green-400">{formatPrice(scale.price)}</span>
                                 </div>
                             ))}
                        </div>
                    </div>
                )}

                {/* 4. DETAILS GRID (Stock & Format) */}
                <div className="grid grid-cols-2 gap-4 mb-8">
                    {/* Stock */}
                    <div className="bg-gray-50 dark:bg-zinc-800 rounded-2xl p-4 flex flex-col gap-2">
                        <div className="flex items-center gap-2 text-gray-400">
                            <Box size={16} />
                            <span className="text-[10px] font-black uppercase tracking-widest">Stock</span>
                        </div>
                        <div className="flex items-center gap-2">
                            <div className={`w-2 h-2 rounded-full ${isOutOfStock ? 'bg-red-500' : 'bg-green-500'}`}></div>
                            <span className={`font-bold text-sm ${isOutOfStock ? 'text-red-500' : 'text-green-600'}`}>
                                {isOutOfStock ? 'Agotado' : `${product.stock} disp.`}
                            </span>
                        </div>
                    </div>
                    {/* Format */}
                    <div className="bg-gray-50 dark:bg-zinc-800 rounded-2xl p-4 flex flex-col gap-2">
                         <div className="flex items-center gap-2 text-gray-400">
                            <Package size={16} />
                            <span className="text-[10px] font-black uppercase tracking-widest">Formato</span>
                        </div>
                        <span className="font-bold text-sm text-gray-900 dark:text-white">
                            {product.unitsPerDisplay || 1} un./Display
                        </span>
                    </div>
                </div>

                {/* Description */}
                {product.description && (
                     <div className="mb-8">
                         <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-3">Descripción</h4>
                         <p className="text-sm leading-relaxed text-gray-600 dark:text-gray-300 font-medium">
                             {product.description}
                         </p>
                     </div>
                )}

                {/* 5. RELATED PRODUCTS */}
                {relatedProducts.length > 0 && (
                    <div className="pb-4">
                        <div className="flex items-center justify-between mb-4">
                            <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Relacionados</h4>
                            <button onClick={onClose} className="text-[10px] font-bold text-brand hover:underline">Ver todos</button>
                        </div>
                        <div className="flex gap-4 overflow-x-auto no-scrollbar pb-4 -mx-6 px-6">
                            {relatedProducts.map(rel => (
                                <div 
                                    key={rel.id} 
                                    className="min-w-[140px] w-[140px] flex flex-col gap-2 cursor-pointer group"
                                    onClick={() => onSelectProduct && onSelectProduct(rel)}
                                >
                                    <div className="aspect-square bg-gray-50 dark:bg-zinc-800 rounded-2xl p-4 flex items-center justify-center border border-gray-100 dark:border-zinc-700">
                                        <CachedImage src={rel.image} className="w-full h-full object-contain group-hover:scale-110 transition-transform duration-300"/>
                                    </div>
                                    <div>
                                        <p className="text-xs font-bold text-gray-900 dark:text-white line-clamp-1">{rel.name}</p>
                                        <p className="text-[10px] text-gray-400">{formatPrice(rel.price)}</p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                )}
            </div>
        </div>

        {/* --- STICKY FOOTER --- */}
        <div className="bg-white dark:bg-zinc-900 border-t border-gray-100 dark:border-zinc-800 p-4 pb-8 md:pb-4 flex items-center gap-4 shadow-[0_-5px_20px_rgba(0,0,0,0.05)]">
            
            {/* Quantity Pill */}
            <div className="flex items-center bg-gray-100 dark:bg-zinc-800 rounded-2xl h-14 px-2 flex-shrink-0">
                <button 
                    onClick={handleDecrement} 
                    disabled={quantity <= 1} 
                    className="w-10 h-full flex items-center justify-center text-gray-500 hover:text-black dark:text-gray-400 disabled:opacity-30 transition-colors"
                >
                    <Minus size={20}/>
                </button>
                <span className="w-8 text-center font-black text-lg text-gray-900 dark:text-white">{quantity}</span>
                <button 
                    onClick={handleIncrement} 
                    disabled={quantity >= product.stock} 
                    className="w-10 h-full flex items-center justify-center text-gray-500 hover:text-black dark:text-gray-400 disabled:opacity-30 transition-colors"
                >
                    <Plus size={20}/>
                </button>
            </div>

            {/* Add Button */}
            <button 
                onClick={() => { onAddToCart(product, quantity); onClose(); }}
                disabled={isOutOfStock}
                className={`
                    flex-1 h-14 rounded-2xl font-black text-sm uppercase tracking-widest flex items-center justify-between px-6 shadow-xl transition-all active:scale-95
                    ${isOutOfStock 
                        ? 'bg-gray-200 text-gray-400 cursor-not-allowed' 
                        : 'bg-brand text-white hover:brightness-110'}
                `}
                style={!isOutOfStock ? { backgroundColor: theme.colors.brand } : {}}
            >
                <div className="flex items-center gap-2">
                    <ShoppingCart size={18} fill="currentColor" className="opacity-50"/>
                    <span>{isOutOfStock ? 'Agotado' : 'Agregar'}</span>
                </div>
                {!isOutOfStock && (
                    <span className="bg-white/20 px-2 py-1 rounded text-xs">
                        {formatPrice(currentPrice)}
                    </span>
                )}
            </button>
        </div>
      </div>

      {/* --- LIGHTBOX / FULL SCREEN ZOOM --- */}
      {isZoomed && (
          <div className="fixed inset-0 z-[150] bg-black flex flex-col animate-in fade-in duration-300">
              <div className="absolute top-0 left-0 right-0 p-4 flex justify-between z-20">
                  <div className="text-white text-xs font-black uppercase tracking-widest bg-black/50 px-3 py-1 rounded-full">
                      {currentImageIndex + 1} / {allImages.length}
                  </div>
                  <button onClick={() => setIsZoomed(false)} className="p-2 bg-white/10 rounded-full text-white hover:bg-white/20">
                      <X size={24}/>
                  </button>
              </div>

              <div 
                  className="flex-1 flex items-center justify-center overflow-hidden"
                  onTouchStart={onTouchStart}
                  onTouchMove={onTouchMove}
                  onTouchEnd={onTouchEnd}
              >
                   <CachedImage 
                        key={`zoom-${currentImageIndex}`}
                        src={allImages[currentImageIndex]} 
                        className="max-w-full max-h-full object-contain p-2 animate-in zoom-in-95 duration-300" 
                    />
              </div>
              
              {/* Lightbox Navigation */}
              {allImages.length > 1 && (
                  <div className="absolute bottom-10 left-0 right-0 flex justify-center gap-6 z-20">
                       <button onClick={prevImage} className="p-4 bg-white/10 hover:bg-white/20 rounded-full text-white backdrop-blur-md transition-colors"><ChevronLeft size={24}/></button>
                       <button onClick={nextImage} className="p-4 bg-white/10 hover:bg-white/20 rounded-full text-white backdrop-blur-md transition-colors"><ChevronRight size={24}/></button>
                  </div>
              )}
          </div>
      )}

    </div>
  );
};

export default ProductModal;
