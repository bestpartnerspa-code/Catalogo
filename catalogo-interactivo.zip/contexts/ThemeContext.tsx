
import React, { createContext, useContext, useEffect, useState } from 'react';
import { ThemeConfig, DEFAULT_THEME } from '../types';
import { dbService } from '../services/db';

interface ThemeContextType {
  theme: ThemeConfig;
  setTheme: (theme: ThemeConfig) => void;
  toggleDarkMode: () => void;
  isLoadingTheme: boolean;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [theme, setThemeState] = useState<ThemeConfig>(DEFAULT_THEME);
  const [isLoadingTheme, setIsLoadingTheme] = useState(true);

  useEffect(() => {
    const loadTheme = async () => {
      try {
        await dbService.connect();
        const storedTheme = await dbService.getTheme();
        const mergedTheme = {
          ...DEFAULT_THEME,
          ...storedTheme,
          // Merge nested objects safely
          appBackground: storedTheme?.appBackground || DEFAULT_THEME.appBackground,
          cardBackground: storedTheme?.cardBackground || DEFAULT_THEME.cardBackground,
          badges: storedTheme?.badges || DEFAULT_THEME.badges,
          darkMode: storedTheme?.darkMode ?? false,
          showPrices: storedTheme?.showPrices ?? DEFAULT_THEME.showPrices ?? true,
          layout: { 
            ...DEFAULT_THEME.layout, 
            ...(storedTheme?.layout || {}),
            shadowIntensity: storedTheme?.layout?.shadowIntensity || DEFAULT_THEME.layout.shadowIntensity
          },
          typography: { ...DEFAULT_THEME.typography, ...(storedTheme?.typography || {}) },
        };
        setThemeState(mergedTheme);
      } catch (e) {
        console.error("Failed to load theme", e);
      } finally {
        setIsLoadingTheme(false);
      }
    };
    loadTheme();
  }, []);

  useEffect(() => {
    const root = document.documentElement;
    const isDark = theme.darkMode;
    
    // Brand colors
    const brand = theme.colors?.brand || DEFAULT_THEME.colors.brand;
    const brandContrast = theme.colors?.brandContrast || DEFAULT_THEME.colors.brandContrast;
    
    // Logic for App Background
    let appBgValue = '#f3f4f6';
    if (isDark) {
        appBgValue = '#0a0a0a';
    } else {
        if (theme.appBackground.type === 'image') {
            appBgValue = `url('${theme.appBackground.value}')`;
        } else {
            appBgValue = theme.appBackground.value;
        }
    }

    // Logic for Card Background (Only applies if not dark mode, or specific override needed)
    // We export variables so ProductCard can use them directly or via class
    let cardBgValue = '#ffffff';
    if (isDark) {
        cardBgValue = '#1e1e1e';
    } else {
        if (theme.cardBackground.type === 'image') {
            // Note: CSS variable for image needs to be handled carefully in component
            // We'll set a generic variable, but ProductCard will read theme state for complex image handling if needed
        } else {
            cardBgValue = theme.cardBackground.value;
        }
    }

    const secondary = isDark ? '#1e1e1e' : (theme.colors?.secondary || '#f3f4f6');

    root.style.setProperty('--brand-color', brand);
    root.style.setProperty('--brand-contrast', brandContrast);
    root.style.setProperty('--secondary-color', secondary);
    root.style.setProperty('--font-family', theme.typography?.fontFamily || 'Inter');
    root.style.setProperty('--app-bg', appBgValue);
    
    // Shadow Logic
    const shadows = {
      none: 'none',
      low: '0 1px 3px 0 rgb(0 0 0 / 0.1), 0 1px 2px -1px rgb(0 0 0 / 0.1)',
      medium: '0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1)',
      high: '0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1)'
    };
    const intensity = theme.layout?.shadowIntensity || 'medium';
    root.style.setProperty('--card-shadow', shadows[intensity]);
    
    // Apply dark class to body for tailwind or custom selectors
    if (isDark) {
      document.body.classList.add('dark');
      root.style.setProperty('--text-main', '#ffffff');
    } else {
      document.body.classList.remove('dark');
      root.style.setProperty('--text-main', theme.colors.text);
    }

  }, [theme]);

  const setTheme = async (newTheme: ThemeConfig) => {
    setThemeState(newTheme);
    await dbService.saveTheme(newTheme);
  };

  const toggleDarkMode = () => {
    const newTheme = { ...theme, darkMode: !theme.darkMode };
    setTheme(newTheme);
  };

  return (
    <ThemeContext.Provider value={{ theme, setTheme, toggleDarkMode, isLoadingTheme }}>
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (!context) throw new Error('useTheme must be used within ThemeProvider');
  return context;
};
