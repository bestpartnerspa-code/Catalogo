
import React, { createContext, useContext, useState } from 'react';
import { Language } from '../types';

const translations = {
  es: {
    searchPlaceholder: 'Buscar por Nombre, Marca o SKU...',
    noProducts: 'No se encontraron productos.',
    brand: 'Marca',
    brands: 'MARCAS',
    categories: 'CATEGORÍAS',
    featured: 'DESTACADO',
    outOfStock: 'AGOTADO',
    unavailable: 'No Disponible',
    total: 'Total',
    quoteTitle: 'Cotización',
    item: 'Producto',
    qty: 'Cant.',
    price: 'Precio',
    subtotal: 'Subtotal',
    configuration: 'CONFIGURACIÓN',
  }
};

interface SettingsContextType {
  language: Language;
  t: (key: string) => string;
  formatPrice: (price: number) => string;
  customerType: 'retail' | 'wholesale';
  setCustomerType: (type: 'retail' | 'wholesale') => void;
  // Added getDisplayPrice to context interface to satisfy usage in components
  getDisplayPrice: (price: number) => number;
}

const SettingsContext = createContext<SettingsContextType | undefined>(undefined);

export const SettingsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language] = useState<Language>('es');
  const [customerType, setCustomerType] = useState<'retail' | 'wholesale'>('retail');

  const t = (key: string) => {
    // @ts-ignore
    return translations[language][key] || key;
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('es-CL', {
      style: 'currency',
      currency: 'CLP',
      minimumFractionDigits: 0,
    }).format(price);
  };

  // Added getDisplayPrice function implementation
  const getDisplayPrice = (price: number) => {
    // Return base price for now; logic for wholesale adjustments can be added here
    return price;
  };

  return (
    <SettingsContext.Provider value={{ language, t, formatPrice, customerType, setCustomerType, getDisplayPrice }}>
      {children}
    </SettingsContext.Provider>
  );
};

export const useSettings = () => {
  const context = useContext(SettingsContext);
  if (!context) throw new Error('useSettings must be used within SettingsProvider');
  return context;
};